package com.example.administrator.locationgeotest;

import android.location.Address;
import android.location.Geocoder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    EditText addrET, latET, lonET;
    TextView contentTV;
    Button showBtn1, showBtn2;

//  위치 정보 서비스를 사용하기 위한 객체를 선언한다.
//  위치 정보 서비스를 사용하기 위해서는 AndroidManifest.xml에 아래의 퍼미션을 추가한다.
//  <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
    Geocoder geocoder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addrET = findViewById(R.id.addrET);
        latET = findViewById(R.id.latET);           // 위도
        lonET = findViewById(R.id.lonET);           // 경도
        contentTV = findViewById(R.id.contentTV);

//      주소 검색 버튼 이벤트 처리
        showBtn1 = findViewById(R.id.showBtn1);
        showBtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//              검색을 위해 입력한 주소를 받는다.
                String searchStr = addrET.getText().toString();
//              주소 정보를 이용해 좌표를 찾는 메소드를 호출한다.
                searchLocation(searchStr);
            }
        });

//      좌표 검색 버튼 이벤트 처리
        showBtn2 = findViewById(R.id.showBtn2);
        showBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//              검색을 위해 입력한 위도와 경도를 받는다.
                String latStr = latET.getText().toString();
                String lonStr = lonET.getText().toString();
                double latitude = 0.0D;
                double longitude = 0.0D;
                try {
//                  문자열로 입력된 위도와 경도를 실수로 바꿔준다.
                    latitude = Double.parseDouble(latStr);
                    longitude = Double.parseDouble(lonStr);
                } catch (NumberFormatException e) {
                    Log.e("예외 : ", e.toString());
                }
//              위도와 경도를 이용해 주소를 찾는 메소드를 호출한다.
                searchLocation(latitude, longitude);
            }
        });

        geocoder = new Geocoder(this, Locale.KOREAN);
//        geocoder = new Geocoder(this, Locale.getDefault());
    }

//  주소를 이용해 위치 좌표를 찾는 메소드
    private void searchLocation(String searchStr) {
//      결과 를 저장할 List 객체를 선언한다.
//      Address는 Geocoder를 이용해 얻어온 주소를 기억하는 객체이다.
        List<Address> addressList = null;
        try {
//          getFromLocationName(주소, 개수) : 입력한 주소 문자열로 검색한다.
//          개수는 좌표에 대해 주소를 리턴받는 갯수로 한 좌표에 대해 두 개 이상의 이름이 존재할 수 있기 때문에
//          주소 배열을 리턴받기 위한 최대 갯수를 설정한다.
//          addressList = geocoder.getFromLocationName(searchStr, 1);
            addressList = geocoder.getFromLocationName(searchStr, 3,
                    -89, -179, 90, 180);
            for(int i=0 ; i<addressList.size() ; i++) {
                Log.e("뭐가 나올까 ", addressList.get(i).toString());
            }
            if(addressList != null) {
                contentTV.setText("\n입력한 [" + searchStr + "]로 검색한 주소의 개수 : " +
                        addressList.size() + "\n");
                for(int i=0 ; i<addressList.size() ; i++) {
//                  Geocoder를 사용해 얻어온 주소 한 건을 얻어온다.
                    Address outAddr = addressList.get(i);
                    StringBuffer outAddrStr = new StringBuffer();
                    int addrCount = outAddr.getMaxAddressLineIndex() + 1;
                    for(int j=0 ; j<addrCount ; j++) {
                        outAddrStr.append(outAddr.getAddressLine(j));
                    }
//                  outAddrStr.append(outAddr.getAddressLine(0));
                    outAddrStr.append("\n위도 : " + outAddr.getLatitude());
                    outAddrStr.append("\n경도 : " + outAddr.getLongitude());
                    contentTV.append("\n" + (i + 1) + "번째 주소 : " + i + " : " + outAddrStr.toString() + "\n");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

//  위도와 경도를 이용해 주소를 찾는 메소드
    private void searchLocation(double latitude, double longitude) {
        List<Address> addressList = null;
        try {
            addressList = geocoder.getFromLocation(latitude, longitude, 3);
            for(int i=0 ; i<addressList.size() ; i++) {
                Log.e("뭐가 나올까 ", addressList.get(i).toString());
            }
            if(addressList != null) {
                contentTV.setText("\n입력한 위도와 경도로 검색한 주소의 개수 : " + addressList.size() + "\n");
                for(int i=0 ; i<addressList.size() ; i++) {
                    Address outAddr = addressList.get(i);
                    StringBuffer outAddrStr = new StringBuffer();
                    int addrCount = outAddr.getMaxAddressLineIndex() + 1;
                    for(int j=0 ; j<addrCount ; j++) {
                        outAddrStr.append(outAddr.getAddressLine(j));
                    }
                    outAddrStr.append("\n위도 : " + outAddr.getLatitude());
                    outAddrStr.append("\n경도 : " + outAddr.getLongitude());
                    contentTV.append("\n" + (i + 1) + "번째 주소 : " + i + " : " + outAddrStr.toString() + "\n");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
