package com.example.administrator.jsontest1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    TextView tv;
//  JSON 배열 => JSONArray 객체로 읽는다.
    String json1 = "[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]";
//  JSON 객체 => JSONObject 객체로 읽는다.
    String json2 = "{name : '홍길동', age : 20}";
//  JSON 객체 배열
    String json3 = "[{name : '임꺽정', age : 38}, {name : 장길산, age : 45}]";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = findViewById(R.id.tv);

        try {
//          JSON 배열을 읽어 저장할 객체를 선언할 때 생성자의 인수로 JSON 배열 객체를 넘겨서 읽는다.
            JSONArray array = new JSONArray(json1);
            tv.append(json1 + " JSON 배열이 저장된 String 출력\n");
            tv.append(array.toString() + " JOSN 배열이 저장된 JSONArray 객체 출력\n");
            for(int i=0 ; i<array.length() ; i++) {
                tv.append("array.get(" + i + ") = " + array.get(i) + "\n");
            }
//          JSON 객체를 읽어 저장할 객체를 선언할 때 생성자의 인수로 JSON 객체를 넘겨서 읽는다.
            JSONObject object = new JSONObject(json2);
            tv.append("=============================\n");
            tv.append(json2 + " JSON 객체가 저장된 String 출력\n");
            tv.append(object.getString("name") + " 님은 " + object.getInt("age") + "살 입니다.\n");
            tv.append(object.getString("name") + " 님은 내년에 " + (object.getInt("age") + 1) +
                    "살 입니다.\n");
            tv.append("=============================\n");
//          JSON 객체 배열 읽기
            JSONArray jsonArray = new JSONArray(json3);
            for(int i=0 ; i<jsonArray.length() ; i++) {
//              JSON 배열에 저장된 내용이 값이면 get() 메소드로 읽으면 되지만 JSON 배열에 저장된 내용이
//              JSON 객체일 경우에는 getJSONObject() 메소드로 읽어야 한다.
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                tv.append(jsonObject.getString("name") + " 님은 " + jsonObject.getInt("age") +
                        "살 입니다.\n");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}








