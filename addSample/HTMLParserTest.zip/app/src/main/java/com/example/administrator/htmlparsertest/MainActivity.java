package com.example.administrator.htmlparsertest;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText yearET, monthET;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        yearET = findViewById(R.id.yearET);
        monthET = findViewById(R.id.monthET);
        listView = findViewById(R.id.listView);
    }

    public void viewCalendar(View view) {
//      EditText에 입력한 년, 월을 얻어온다.
        int year = Integer.parseInt(yearET.getText().toString());
        int month = Integer.parseInt(monthET.getText().toString());
//      파싱을 하기위해 얻어올 웹 페이지의 주소를 만든다.
        String urlAddr =
                String.format("https://astro.kasi.re.kr:444/life/pageView/5?search_year=%d&search_month=%02d",
                        year, month);
//      Log.e("viewCalendar() ", urlAddr);
//      HTML 파싱에 사용할 내부 클래스의 객체에서 execute() 메소드를 실행한다.
//      execute() 메소드의 인수로 적어준 내용이 HTML 파싱에 사용할 객체의 가변 인자로 전달된다.
        new CalendarTask().execute(urlAddr);
    }

//  Jsoup 외부 라이브러리를 사용해 HTML 파싱에 사용할 내부 클래스를 AsyncTask 클래스를 상속받아 만든다.
//  AsyncTask 클래스의 Void는 첫 문자가 대문자인것에 주의한다.
    class CalendarTask extends AsyncTask<String, Void, Void> {

//      읽어온 HTML 문서를 파싱한 내용을 ListView에 넣어주기 위해 기억할 객체를 선언한다.
        ArrayList<String> list = new ArrayList<>();

//      AsyncTask 클래스를 상속받은 객체에서 execute() 메소드가 실행될 때 자동으로 실행되는 메소드로 백 그라운드
//      작업을 한다.
        @Override
        protected Void doInBackground(String... strings) {
            String urlAddr = strings[0];
//          Log.e("doInBackground() ", urlAddr);
//          Jsoup 라이브러리을 사용해 HTML을 파싱한다.
//          읽어온 HTML 파일을 저장할 객체를 생성한다.
            Document doc = null;
            try {
//              urlAddr에 저장된 주소의 HTML 코드 내용을 얻어온다.
                doc = Jsoup.connect(urlAddr).get();
//              Log.e("doc ", String.format("%s", doc));
//              읽어온 HTML 코드 내용에서 select() 메소드의 인수로 지정된 table 태그 안의 tbody 태그 안의
//              tr 태그 내부의 내용만 읽어 Elements 객체에
//              저장시킨다.
                Elements element = doc.select("table tbody tr");
//              Elements 객체에 저장된 데이터의 개수 만큼 반복하며 Solar2Lunar 클래스 객체에 저장시킨다.
                for(Element ele : element) {
//                  Log.e("ele ", String.format("%s", ele));
//                  첫번째 td 태그는 양력, 두번째 td 태그는 음력, 세번째 td 태그는 간지를 의미하므로 td 태그
//                  단위로 파싱한다.
                    Elements elements = ele.select("td");
//                  text() : 파싱된 내용에서 태그 내부의 문자열만 얻어온다.
//                  Log.e("양력 ", String.format("%s", elements.get(0).text()));
//                  Log.e("음력 ", String.format("%s", elements.get(1).text()));
//                  Log.e("간지 ", String.format("%s", elements.get(2).text()));
                    Solar2Lunar solar2Lunar = new Solar2Lunar();
                    solar2Lunar.setSolar(elements.get(0).text());
                    solar2Lunar.setLunar(elements.get(1).text());
                    solar2Lunar.setGanji(elements.get(2).text());
//                  ListView에 출력할 형태로 문자열을 편집해서 ArrayList에 저장시킨다.
                    String str = String.format("%02d. %02d-%s(%s)", solar2Lunar.getDate(),
                            solar2Lunar.getLMonth(), solar2Lunar.getLDate(), solar2Lunar.getGDate());
//                  Log.e("ListView ", str);
                    list.add(str);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

//      doInBackground() 메소드가 실행된 후 리턴되면 onPostExecute() 메소드가 자동으로 실행된다.
//      onPostExecute() 메소드에서 Adapter를 만들어 파싱된 HTML 파일의 내용을 ListView에 넣어주면 된다.
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            ArrayAdapter<String> adapter =
                    new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1,
                            list);
            listView.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        }
    }

}
