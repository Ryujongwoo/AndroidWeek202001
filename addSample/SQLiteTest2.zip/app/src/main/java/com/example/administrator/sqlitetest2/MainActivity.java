package com.example.administrator.sqlitetest2;

import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    SQLiteDatabase database;
    ArrayList<String> list = new ArrayList<>();
    ArrayAdapter<String> adapter;

    TextView textView;
    EditText nameET, ageET;
    Button saveBtn, updateBtn;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textView);
        nameET = findViewById(R.id.nameET);
        ageET = findViewById(R.id.ageET);
        saveBtn = findViewById(R.id.saveBtn);
        updateBtn = findViewById(R.id.updateBtn);
        listView = findViewById(R.id.listView);

//      처음에는 update 버튼을 비활성화 시킨다.
        updateBtn.setEnabled(false);

//      데이터베이스가 없으면 만들고 있으면 열어준다.
        database = openOrCreateDatabase("person.db", MODE_PRIVATE, null);
//      데이터베이스에 테이블을 만든다.
        try {
            StringBuffer sb = new StringBuffer();
            sb.append("create table person (");
            sb.append("idx integer primary key, ");
            sb.append("name char(20) not null, ");
            sb.append("age integer default 0)");
            database.execSQL(sb.toString());
            Log.e("sqlite ", "테이블 생성 성공");
        } catch (Exception e) {
            Log.e("sqlite ", "테이블이 이미 존재합니다.");
        }

//      테이블에서 모든 데이터를 얻어와 ListView에 뿌려줘야 한다.
        selectAll();

//      ListView를 클릭하면 클릭된 데이터를 수정할 수 있도록 EditText에 뿌려주고 저장하기 버튼은 비활성화 시키고
//      수정하기 버튼은 활성화 시킨다.
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//              split() 메소드의 구분자로 특수문자를 사용할 때 에러가 발생되면 "\\"를 붙여준다.
                textView.setText(list.get(i).split("\\.")[0]);
                String str = list.get(i).split("\\.")[1];
                nameET.setText(str.split("\\(")[0].trim());
                ageET.setText(str.split("\\(")[1].split("세")[0]);
                saveBtn.setEnabled(false);
                updateBtn.setEnabled(true);
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setTitle("삭제 확인")
                        .setMessage("정말로 삭제하시겠습니까?")
                        .setPositiveButton("예", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                int idx = Integer.parseInt(textView.getText().toString());
                                StringBuffer sb = new StringBuffer();
                                sb.append("delete from person where idx = " + idx);
                                database.execSQL(sb.toString());
                                selectAll();
                                textView.setText("");
                                nameET.setText("");
                                ageET.setText("");
                                nameET.requestFocus();
                            }
                        })
                        .setNegativeButton("아니오", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                textView.setText("");
                                nameET.setText("");
                                ageET.setText("");
                                nameET.requestFocus();
                            }
                        })
                        .create()
                        .show();
                return false;
            }
        });

    }

//  테이블에 저장된 전체 데이터를 얻어와서 ListView에 뿌려주는 메소드
    private void selectAll() {
        list.clear();
        StringBuffer sb = new StringBuffer();
        sb.append("select * from person order by idx desc");
        Cursor cursor = database.rawQuery(sb.toString(), null);
        if(cursor.moveToNext()) {
            do {
                int idx = cursor.getInt(0);
                String name = cursor.getString(1);
                int age = cursor.getInt(2);
                list.add(idx + ". " + name + "(" + age + "세)\n");
            } while(cursor.moveToNext());
        } else {
            list.add("데이터가 없습니다.");
        }
        adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    public void saveBtn(View view) {
        try {
//          EditText에 입력한 내용을 받는다.
            String name = nameET.getText().toString();
            final String age = ageET.getText().toString();
//          이름과 나이가 모두 입력된 경우에만 테이블에 저장한다.
            if(name != null && name.trim().length() > 0 && age != null && age.trim().length() > 0) {
                StringBuffer sb = new StringBuffer();
                sb.append("insert into person (name, age) values (");
                sb.append("'" + name + "', " + age + ")");
                database.execSQL(sb.toString());
                nameET.setText("");
                ageET.setText("");
                nameET.requestFocus();
//              Log.e("sqlite ", "저장 완료!!!");
                selectAll();
            } else {
//              경고창 띄우기
                AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setTitle("저장 실패!!!")
                        .setMessage("이름 또는 나이를 입력하지 않거나 잘못된 데이터를 입력했습니다.")
                        .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                nameET.setText("");
                                ageET.setText("");
                                nameET.requestFocus();
                            }
                        })
                        .create()
                        .show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("sqlite ", "저장 실패!!!");
        }

    }

    public void updateBtn(View view) {
        try {
//          TextView와 EditText에 입력된 내용을 받는다.
            String idx = textView.getText().toString();
            String name = nameET.getText().toString();
            final String age = ageET.getText().toString();
            if(name != null && name.trim().length() > 0 && age != null && age.trim().length() > 0) {
                StringBuffer sb = new StringBuffer();
                sb.append("update person set name = '" + name + "', ");
                sb.append("age = " + age + " where idx = " + idx);
                database.execSQL(sb.toString());
                selectAll();
                textView.setText("");
                nameET.setText("");
                ageET.setText("");
                nameET.requestFocus();
                saveBtn.setEnabled(true);
                updateBtn.setEnabled(false);
                Log.e("sqlite ", "수정 성공!!!");
            } else {
//              경고창 띄우기
                AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setTitle("수정 실패!!!")
                        .setMessage("이름 또는 나이를 입력하지 않거나 잘못된 데이터를 입력했습니다.")
                        .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                nameET.setText("");
                                ageET.setText("");
                                nameET.requestFocus();
                            }
                        })
                        .create()
                        .show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("sqlite ", "수정 실패!!!");
        }
    }
}
