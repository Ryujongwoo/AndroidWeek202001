package com.example.administrator.sqlitetest1;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    TextView textView;
//  안드로이드에서 database를 사용하기 위해 SQLite 객체를 선언한다.
    SQLiteDatabase sqLiteDatabase;
    String dbName = "mydb.db";          // database 이름

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textView);

//      database를 만드는 메소드를 실행한다.
        sqLiteDatabase = createDatabase();
//      File file = getDatabasePath(dbName);
//      exists() : 파일 객체가 있으면 true, 없으면 false를 리턴한다.
//      if (file.exists()) {
//          Log.e("sqlite ", file.getAbsolutePath() + " 생성 성공");
//      } else {
//          Log.e("sqlite ", file.getAbsolutePath() + " 생성 실패");
//      }

//      테이블을 만드는 메소드를 실행한다.
        createTable("sample");
//      테이블에 데이터를 저장하는 메소드를 실행한다.
        insertData("홍길동", 20);
        insertData("임꺽정", 38);
        insertData("장길산", 45);
        insertData("일지매", 18);
//      테이블에 저장된 모든 데이터를 얻어오는 메소드를 실행한다.
        selectAll();
//      지정된 id에 해당되는 데이터 한 건을 얻어오는 메소드를 실행한다.
        selectByIdx(3000);
    }

//  database를 만드는 메소드
    private SQLiteDatabase createDatabase() {
//      지정된 이름의 데이터베이스가 있으면 열고 없으면 새로 만든다.
        return openOrCreateDatabase(dbName, MODE_PRIVATE, null);
    }

//  table을 만드는 메소드
    private void createTable(String tableName) {
        try {
//          SQL 명령을 문자열로 만든다.
//          StringBuffer를 사용하는것이 String을 사용하는 것 보다 빠르다.
            StringBuffer sql = new StringBuffer();
            sql.append("create table " + tableName + " (");
            sql.append("idx integer primary key, ");
            sql.append("name char(10) not null, ");
            sql.append("age integer default 0)");
//          SQL 명령을 실행한다.
            sqLiteDatabase.execSQL(sql.toString());
            Log.e("sqlite ", "sample 테이블 생성 성공");
        } catch (Exception e) {
            Log.e("sqlite ", "sample 테이블이 이미 존재합니다.");
        }
    }

//  테이블에 데이터를 저장하는 메소드
    private void insertData(String name, int age) {
        try {
            StringBuffer sql = new StringBuffer();
//          문자열을 반드시 양쪽에 따옴표를 붙여줘야 한다.
            sql.append("insert into sample (name, age) values (");
            sql.append("'" + name + "', " + age + ")");
            sqLiteDatabase.execSQL(sql.toString());
            Log.e("sqlite ", "sample 테이블에 " + name + " 데이터 추가 성공");
        } catch (Exception e) {
            Log.e("sqlite ", "sample 테이블에 " + name + " 데이터 추가 실패");
        }
    }

//  테이블에 저장된 전체 데이터를 얻어오는 메소드
    private void selectAll() {
        String sql = "select * from sample order by idx desc";
//      Cursor 객체에 select 명령의 결과를 저장한다.
//      execSQL() : 테이블의 내용이 변경되는 SQL 명령을 실행한다. insert, delete, update
//      rawQuery() : 테이블의 내용이 변경되지 않는 SQL 명령을 실행한다.
        Cursor cursor = sqLiteDatabase.rawQuery(sql, null);
//      getCount() : Cursor 객체에 저장된 select 명령이 실행된 후 얻어온 데이터의 개수를 얻어온다.
//      Log.e("sqlite ", "sample 테이블에 저장된 데이터는 " + cursor.getCount() + "개 입니다.");
        textView.setText("sample 테이블에 저장된 데이터는 " + cursor.getCount() + "개 입니다.\n");
//      Cursor 객체에 저장된 데이터의 개수만큼 반복하며 Cursor 객체의 데이터를 얻어온다.
//      moveToNext() : Cursor 객체에 저장된 다음 데이터가 있으면 데이터를 얻어오고 true를 리턴한다.
//      Cursor 객체에 저장된 다음 데이터가 없으면 false를 리턴한다.
//      cursor.moveToNext() : 자바의 rs.next()와 같은 표현이다.
        while(cursor.moveToNext()) {
            int idx = cursor.getInt(0);
            String name = cursor.getString(1);
            int age = cursor.getInt(2);
//          Log.e("sqlite ", idx + ". " + name + "(" + age + ")");
            textView.append(idx + ". " + name + "(" + age + ")\n");
        }
    }

//  테이블에 저장된 글 중에서 지정된 글 번호에 해당되는 글을 얻어오는 메소드
    private void selectByIdx(int idx) {
        String sql = "select * from sample where idx = " + idx;
        Cursor cursor = sqLiteDatabase.rawQuery(sql, null);
        if(cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            int age = cursor.getInt(2);
            textView.append(id + ". " + name + "(" + age + ")\n");
        } else {
            textView.append(idx + "번 글이 존재하지 않습니다.");
        }
    }
}
