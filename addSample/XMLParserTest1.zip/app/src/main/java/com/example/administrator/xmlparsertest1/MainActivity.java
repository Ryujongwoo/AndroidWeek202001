package com.example.administrator.xmlparsertest1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

public class MainActivity extends AppCompatActivity {

    TextView tv;
    StringBuffer stringBuffer = new StringBuffer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = findViewById(R.id.tv);

//      파싱할 xml 파일의 내용을 약식으로 만든다.
        stringBuffer.append("<root>");
            stringBuffer.append("<item id='1'>");
                stringBuffer.append("홍길동");
            stringBuffer.append("</item>");
            stringBuffer.append("<item id='2'>");
                stringBuffer.append("임꺽정");
            stringBuffer.append("</item>");
            stringBuffer.append("<item id='3'>");
                stringBuffer.append("장길산");
            stringBuffer.append("</item>");
        stringBuffer.append("</root>");

//      XML의 파싱 방법은 DOM(Document Object Model) 방식과 SAX(Simple API for XML) 방식이 있다.
        try {
//          DOM(Document Object Model)
//              XML 문서 전체를 메모리에 읽어서 파싱한다.
//              XML 문서 전체가 메모리에 올라와 있으므로 노드(태그)들을 빠르게 검색하고 데이터 수정과 구조 변경에
//              용이하다.

//          파싱할 XML을 읽어 메모리에 저장시키기 위해서 InputSource 객체를 만든다.
            InputSource source = new InputSource();
//          파싱할 XML을 읽는다.
            source.setCharacterStream(new StringReader(stringBuffer.toString()));

//          XML을 파싱하기 위해 DocumentBuilderFactory 객체를 생성하고 객체를 얻어온다.
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
//          DocumentBuilderFactory 객체로 DocumentBuilder 객체를 생성한다.
            DocumentBuilder builder = factory.newDocumentBuilder();

//          XML을 파싱해서 Document(org.w3c.dom 패키지) 객체를 생성한다.
            Document document = builder.parse(source);
//          XML의 노드(태그) 이름으로 찾아서 태그 단위로 구분된 NodeList 객체를 생성한다.
            NodeList nodeList = document.getElementsByTagName("item");

            StringBuffer str = new StringBuffer();
//          파싱된 태그의 개수 만큼 반복하며 필요한 처리를 한다.
//          getLength() : NodeList 객체에 저장된 파싱된 XML 태그의 개수를 얻어온다.
            for(int i=0 ; i<nodeList.getLength() ; i++) {
//              파싱된 XML은 Element 객체 타입으로 리턴되므로 Element(org.w3c.dom 패키지) 객체에 저장시켜
//              처리한다.
                Element element = (Element) nodeList.item(i);
//              getAttribute() : Element 객체에서 태그의 속성을 얻어온다.
//              getTextContent() : Element 객체에서 태그 내부의 내용을 얻어온다.
//              Log.e("엑스엠엘 ", element.getAttribute("id") + ". " + element.getTextContent());
                str.append(element.getAttribute("id") + ". " + element.getTextContent() + "\n");
            }
            tv.setText(str.toString());

//          SAX(Simple API for XML)
//              XML 문서를 처음 부터 순차적으로 읽어 내려가며 노드(태그)가 열리고 닫히는 부분에서 이벤트를 발생시켜
//              처리한다.
//              XML 문서 전체를 메모리에 올리지 않기 때문에 메모리 사용량이 적고 단순히 읽기만 할 경우 속도가 빠르다.
//              발생한 이벤트를 핸들링 하여 변수에 저장하고 활용하는 방식이기 때문에 문서의 중간을 검색하거나
//              노드를 수정하기가 어렵다.

//          파싱할 XML을 읽어 메모리에 저장시키기 위해서 InputSource 객체를 만든다.
            InputSource source1 = new InputSource();
//          파싱할 XML을 읽는다.
            source1.setCharacterStream(new StringReader(stringBuffer.toString()));
//          SAX 방식의 파싱을 하기 위해서 SAXParser를 만든다.
            SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
//          생성된 SAXParser 객체를 이용해 XML 문서를 파싱한다.
//          parse(파싱할 XML 문서가 저장된 InputSource 객체, 이벤트를 발생시킬 내부 클래스 객체)
            parser.parse(source1, new MyHandler());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

//  SAX 방식의 파싱이 실행될 때 이벤트를 발생시킬 내부 클래스를 DefaultHandler 클래스를 상속받아 만든다.
    class MyHandler extends DefaultHandler {

//      XML 문서가 시작될 때 자동으로 실행되는 메소드
        @Override
        public void startDocument() throws SAXException {
            super.startDocument();
            Log.e("SAX 파싱 ", "XML 문서 시작");
        }

//      XML 문서가 끝날 때 자동으로 실행되는 메소드
        @Override
        public void endDocument() throws SAXException {
            super.endDocument();
            Log.e("SAX 파싱 ", "XML 문서 끝");
        }

//      태그가 시작될 때 자동으로 실행되는 메소드
        @Override
        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            super.startElement(uri, localName, qName, attributes);
            Log.e("XML 태그 시작 ", "<" + qName + ">");
//          Log.e("uri ", uri.equals("") ? "공백" : uri);
//          Log.e("localName ", localName);
        }

//      태그가 끝날 때 자동으로 실행되는 메소드
        @Override
        public void endElement(String uri, String localName, String qName) throws SAXException {
            super.endElement(uri, localName, qName);
            Log.e("XML 태그 끝 ", "</" + qName + ">");
        }

//      태그 사이의 텍스트를 만날 때 자동으로 실행되는 메소드
        @Override
        public void characters(char[] ch, int start, int length) throws SAXException {
            super.characters(ch, start, length);
//          Log.e("start ", start + "");
//          Log.e("length ", length + "");
//          Log.e("태그 사이의 텍스트 ", String.valueOf(ch).trim());
            String tag = new String(ch, start, length);
            Log.e("태그 사이의 텍스트 ", tag);
        }
    }

}
