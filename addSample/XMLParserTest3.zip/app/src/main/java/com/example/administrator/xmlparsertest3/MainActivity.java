package com.example.administrator.xmlparsertest3;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    TextView tv;
    ArrayList<Book> list = new ArrayList<>();       // XML 데이터 여러건을 기억할 ArrayList

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = findViewById(R.id.tv);
        tv.setText(getXMLDate());
    }

    private String getXMLDate() {
        StringBuffer stringBuffer = new StringBuffer();
        try {
//          res 폴더 아래의 raw 폴더에 저장된 XML 파일을 읽어 파싱을 하기 위해 XmlPullParser 객체에 저장한다.
//          XmlPullParser parser = XmlPullParserFactory.newInstance().newPullParser();
//          getResources() : res 폴더의 정보를 얻어온다.
//          openRawResource() : res 폴더 아래의 raw 폴더의 정보를 얻어온다.
//          XML 파일을 읽어들일 때 한글이 깨지는 것을 방지하기 위해 반드시 UTF-8로 캐릭터 셋을 맞춰야한다.
//          parser.setInput(getResources().openRawResource(R.raw.data), "UTF-8");

//          res 폴더 아래의 xml 폴더에 저장된 XML 파일을 읽어 파싱을 하기 위해 XmlPullParser 객체에 저장한다.
            XmlPullParser parser = getResources().getXml(R.xml.data);

//          파싱할 태그의 개수만큼 논리형 변수를 선안하고 false로 초기화 시킨다.
            boolean isBook = false, isTitle = false, isAuthor = false, isYear = false, isPrice = false;
            String tagName = "";        // 태그 이름을 기억할 변수
            Book book = null;           // XML 데이터 한 건을 기억할 클래스 객체를 선언한다.

//          파싱을 하기 위해 최초의 이벤트를 받는다.
//          START_DOCUMENT : 문서의 시작, END_DOCUMENT : 문서의 끝, START_TAG : 태그의 시작
//          END_TAG : 태그의 끝, TEXT : 태그 사이의 텍스트
            int eventType = parser.getEventType();      // 최초의 이벤트는 getEventType() 메소드로 받는다.
//          Log.e("XML 파일 시작 ", eventType == XmlPullParser.START_DOCUMENT ? "읽기 시작" : "못읽음");

//          XML 파일의 마지막 까지 반복하며 파싱한다.
            while(eventType != XmlPullParser.END_DOCUMENT) {
//              switch를 이용해서 발생한 이벤트 별로 필요한 처리를 한다.
                switch (eventType) {
                    case XmlPullParser.START_TAG:
//                      이벤트가 발생한 태그의 이름을 얻어와서 태그 별로 필요한 처리를 한다.
                        tagName = parser.getName();
                        switch (tagName.toLowerCase()) {
                            case "book":
                                isBook = true;
                                book = new Book();      // XML 데이터 한 건을 기억할 클래스 객체를 선언한다.
//                              getAttributeName() : 태그의 속성 이름을 얻어온다.
//                              getAttributeValue() : 태그의 속성 값을 얻어온다.
//                              Log.e("태그의 속성", parser.getAttributeName(0) + " : " +
//                                      parser.getAttributeValue(0));
                                book.setCategory(parser.getAttributeValue(0));
                                break;
                            case "title":
                                isTitle = true;
                                book.setLang(parser.getAttributeValue(0));
                                break;
                            case "author":
                                isAuthor = true; break;
                            case "year":
                                isYear = true; break;
                            case "price":
                                isPrice = true; break;
                        }
                        break;
                    case XmlPullParser.END_TAG:
                        tagName = parser.getName();
                        switch (tagName.toLowerCase()) {
                            case "book":
                                isBook = false;
                                list.add(book);
//                              Log.e("book ", book.toString());
                                break;
                            case "title":
                                isTitle = false; break;
                            case "author":
                                isAuthor = false; break;
                            case "year":
                                isYear = false; break;
                            case "price":
                                isPrice = false; break;
                        }
                        break;
                    case XmlPullParser.TEXT:
                        if(isBook && isTitle) {
                            book.setTitle(parser.getText());
                        }
                        if(isBook && isAuthor) {
                            book.setAuthor(parser.getText());
                        }
                        if(isBook && isYear) {
                            book.setYear(parser.getText());
                        }
                        if(isBook && isPrice) {
                            book.setPrice(parser.getText());
                        }
                        break;
                }
//              두 번째 이벤트 부터는 getEventType() 메소드가 아닌 next() 메소드로 받아야 한다.
//              이 문장을 쓰지 않으면 eventType 변수에는 최초에 받아들인 이벤트인 START_DOCUMENT가 계속 남아있어
//              while 문장의 조건 eventType != XmlPullParser.END_DOCUMENT이 항상 참이 되므로 while은 무한 루프가
//              되며 정상적인 처리가 되지 않는다. => 이거 안적어서 30분을 버벅거림..... 정신줄 챙기자.....
                eventType = parser.next();
            }

            for(Book b : list) {
                stringBuffer.append(b.getTitle() + " : " + b.getAuthor() + "(" + b.getPrice() + "달러)\n");
            }

        } catch (XmlPullParserException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return stringBuffer.toString();
    }
}
