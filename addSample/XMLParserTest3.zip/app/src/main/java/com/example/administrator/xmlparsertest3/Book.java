package com.example.administrator.xmlparsertest3;

//  아래와 같이 구성된 XML 데이터 한 건을 기억할 클래스
//  <book category="cooking">
//      <title lang="en">Everyday Italian</title>
//      <author>Giada De Laurentiis</author>
//      <year>2005</year>
//      <price>30.00</price>
//  </book>

public class Book {

    String category;        // 카테고리, 태그의 속성
    String lang;            // 언어, 태그의 속성
    String title;           // 도서명, 태그의 내용
    String author;          // 저자, 태그의 내용
    String year;            // 출판년도, 태그의 내용
    String price;           // 가격(달러), 태그의 내용

    public String getCategory() {
        return category;
    }
    public void setCategory(String category) {
        this.category = category;
    }
    public String getLang() {
        return lang;
    }
    public void setLang(String lang) {
        this.lang = lang;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getAuthor() {
        return author;
    }
    public void setAuthor(String author) {
        this.author = author;
    }
    public String getYear() {
        return year;
    }
    public void setYear(String year) {
        this.year = year;
    }
    public String getPrice() {
        return price;
    }
    public void setPrice(String price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Book{" +
                "category='" + category + '\'' +
                ", lang='" + lang + '\'' +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", year='" + year + '\'' +
                ", price='" + price + '\'' +
                '}';
    }

}
