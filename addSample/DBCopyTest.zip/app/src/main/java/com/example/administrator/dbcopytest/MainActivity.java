package com.example.administrator.dbcopytest;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

//  외부에서 데이터베이스를 만들었다면 최초 설치시 데이터베이스를 database 폴더로 복사해준다.
//  프로그램이 실행될 때 데이터베이스 존재 여부를 판단해서 데이터베이스를 복사한다.

public class MainActivity extends AppCompatActivity {

    String dbName = "word1000.sqlite";
    SQLiteDatabase database;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.listView);

//      데이터베이스가 존재하는지 판단해서 존재하지 assets 폴더나 res 폴더 아래 raw 폴더의 데이터베이스를
//      복사해 넣는다.
        if(!isDatabase()) {
            try {
//              데이터베이스가 저장될 폴더가 존재하지 않으면 폴더를 만든다.
//              getPackageName() : 현재 프로젝트의 패키지 이름을 얻어온다.
//              Log.e("패키지 이름 ", getPackageName());
//              데이터베이스가 저장될 경로를 만든다.
                String dbPath = "/data/data/" + getPackageName() + "/databases/";
//              Log.e("dbpath ", dbPath);

//              데이터베이스가 저장될 폴더가 없으면 폴더를 생성한다. => 하위 버전의 안드로이드를 위해 코딩한다.
                File path = new File(dbPath);
                if(!path.exists()) {
//                  mkdir() : 지정된 경로에 폴더를 만든다.
                    path.mkdir();
//                  Log.e("폴더 생성 ", path.getAbsolutePath());
                }

//              데이터베이스를 저장할 폴더가 존재하므로 assets 폴더나 res 폴더 아래 raw 폴더의 데이터베이스를
//              복사해서 넣어준다.
//              데이터베이스 파일을 만든다.
                File file = new File(dbPath + "/" + dbName);
                file.createNewFile();
//              assets 폴더나 res 폴더 아래 raw 폴더의 데이터베이스를 읽어서 저장하기 위해 FileOutputStream
//              객체를 생성한다.
                FileOutputStream fos = new FileOutputStream(file);
//              InputStream 객체에 assets 폴더의 데이터베이스를 읽어들인다.
//              InputStream is = getAssets().open(dbName);
//              InputStream 객체에 res 폴더 아래 raw 폴더의 데이터베이스를 읽어들인다.
                InputStream is = getResources().openRawResource(R.raw.word1000);

                byte[] bytes = new byte[1024];
                int len = 0;
//              InputStream 객체에서 읽어들인 내용이 있는 동안 반복하며 FileOutputStream 객체로 복사한다.
//              is.read(bytes) => InputStream 객체에서 bytes 배열의 크기 만큼 읽어들인다.
//              len = is.read(bytes) => 읽어들인 크기를 len 변수에 저장한다.
//              (len = is.read(bytes)) != -1 => InputStream 객체에서 읽어들인 내용이 없으면
                while((len = is.read(bytes)) != -1) {
//                  InputStream 객체에서 읽어 bytes 배열에 저장한 내용의 처음(0) 부터 끝(len) 까지 저장한다.
                    fos.write(bytes, 0, len);
//                  flush() : 출력 버퍼가 가득차지 않았더라도 저장한다.
                    fos.flush();
                }
//              데이터베이스 복사에 사용한 객체를 닫는다.
                is.close();
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Log.e("데이터베이스 복사 완료 ", getDatabasePath(dbName).getAbsolutePath());
        }

//      데이터베이스를 읽어서 ListView에 뿌린다.
//      복사된 데이터베이스를 열어준다.
        database = openOrCreateDatabase(dbName, MODE_PRIVATE, null);
        String sql = "select rowid as _id, col_3, col_4, col_5 from china8 where col_3 is not null";
        Cursor cursor = database.rawQuery(sql, null);
//      while(cursor.moveToNext()) {
//          Log.e("hanja ", cursor.getString(0) + " " + cursor.getString(1) + " " +
//              cursor.getString(2));
//      }

//      SimpleCursorAdapter를 이용하면 쿼리 결과를 바로 ListView에 넣어줄 수 있다.
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(getApplicationContext(), R.layout.listitem,
                cursor, new String[] {"col_3", "col_4", "col_5"}, new int[] {R.id.hanjaTV, R.id.hangulTV,
                R.id.contentTV});
        listView.setAdapter(adapter);
    }

//  데이터베이스의 존재 여부를 판단하는 메소드
    private boolean isDatabase() {
//      데이터베이스 파일의 객체를 얻어온다.
        File file = getDatabasePath(dbName);
//      데이터베이스의 존재 여부를 판단해서 있으면 true 없으면 false를 리턴시킨다.
//      Log.e("데이터베이스 ", file.exists() ? "있음" : "없음");
        return file.exists() ? true : false;
    }

}
