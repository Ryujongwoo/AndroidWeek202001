package com.example.administrator.jsontest2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    TextView tv1, tv2, tv3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        tv1 = findViewById(R.id.tv1);
        tv2 = findViewById(R.id.tv2);
        tv3 = findViewById(R.id.tv3);
//      MainActivity에서 ListView가 터치되면 Intent에 저장되서 넘어오는 데이터를 받는다.
        Intent intent = getIntent();
        /*
//      사자성어
        Data data = intent.getParcelableExtra("data");
        tv1.setText(data.getH());
        tv2.setText(data.getK());
        tv3.setText(data.getT());
        */
//      한자검정
        Dic dic = intent.getParcelableExtra("data");
        tv1.setText(dic.getH());
        tv2.setText(dic.getM() + " " + dic.getM1());
        tv3.setText(dic.getD());
    }

    public void goBack(View view) {
        finish();
    }

}
