package com.example.administrator.jsontest2;

import android.os.Parcel;
import android.os.Parcelable;

public class Data implements Parcelable {

//  멤버 이름은 JSON 객체의 key 이름과 동일하게 만들어야 한다.
    String l;
    String h;
    String h1;
    String h2;
    String h3;
    String h4;
    String k;
    String k1;
    String k2;
    String k3;
    String k4;
    String t;

    protected Data(Parcel in) {
        l = in.readString();
        h = in.readString();
        h1 = in.readString();
        h2 = in.readString();
        h3 = in.readString();
        h4 = in.readString();
        k = in.readString();
        k1 = in.readString();
        k2 = in.readString();
        k3 = in.readString();
        k4 = in.readString();
        t = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(l);
        dest.writeString(h);
        dest.writeString(h1);
        dest.writeString(h2);
        dest.writeString(h3);
        dest.writeString(h4);
        dest.writeString(k);
        dest.writeString(k1);
        dest.writeString(k2);
        dest.writeString(k3);
        dest.writeString(k4);
        dest.writeString(t);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Data> CREATOR = new Creator<Data>() {
        @Override
        public Data createFromParcel(Parcel in) {
            return new Data(in);
        }

        @Override
        public Data[] newArray(int size) {
            return new Data[size];
        }
    };

    public String getL() {
        return l;
    }
    public void setL(String l) {
        this.l = l;
    }
    public String getH() {
        return h;
    }
    public void setH(String h) {
        this.h = h;
    }
    public String getH1() {
        return h1;
    }
    public void setH1(String h1) {
        this.h1 = h1;
    }
    public String getH2() {
        return h2;
    }
    public void setH2(String h2) {
        this.h2 = h2;
    }
    public String getH3() {
        return h3;
    }
    public void setH3(String h3) {
        this.h3 = h3;
    }
    public String getH4() {
        return h4;
    }
    public void setH4(String h4) {
        this.h4 = h4;
    }
    public String getK() {
        return k;
    }
    public void setK(String k) {
        this.k = k;
    }
    public String getK1() {
        return k1;
    }
    public void setK1(String k1) {
        this.k1 = k1;
    }
    public String getK2() {
        return k2;
    }
    public void setK2(String k2) {
        this.k2 = k2;
    }
    public String getK3() {
        return k3;
    }
    public void setK3(String k3) {
        this.k3 = k3;
    }
    public String getK4() {
        return k4;
    }
    public void setK4(String k4) {
        this.k4 = k4;
    }
    public String getT() {
        return t;
    }
    public void setT(String t) {
        this.t = t;
    }

    @Override
    public String toString() {
        return "Data{" + "l='" + l + '\'' + ", h='" + h + '\'' + ", h1='" + h1 + '\'' + ", h2='" + h2 + '\'' +
                ", h3='" + h3 + '\'' + ", h4='" + h4 + '\'' + ", k='" + k + '\'' + ", k1='" + k1 + '\'' +
                ", k2='" + k2 + '\'' + ", k3='" + k3 + '\'' + ", k4='" + k4 + '\'' + ", t='" + t + '\'' + '}';
    }

}
