package com.example.administrator.jsontest2;

import android.os.Parcel;
import android.os.Parcelable;

public class Dic implements Parcelable {

    String d;
    String h;
    String m;
    String m1;
    String m2;
    String m3;
    String m4;
    String m5;
    String r;
    String ld;

    protected Dic(Parcel in) {
        d = in.readString();
        h = in.readString();
        m = in.readString();
        m1 = in.readString();
        m2 = in.readString();
        m3 = in.readString();
        m4 = in.readString();
        m5 = in.readString();
        r = in.readString();
        ld = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(d);
        dest.writeString(h);
        dest.writeString(m);
        dest.writeString(m1);
        dest.writeString(m2);
        dest.writeString(m3);
        dest.writeString(m4);
        dest.writeString(m5);
        dest.writeString(r);
        dest.writeString(ld);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Dic> CREATOR = new Creator<Dic>() {
        @Override
        public Dic createFromParcel(Parcel in) {
            return new Dic(in);
        }

        @Override
        public Dic[] newArray(int size) {
            return new Dic[size];
        }
    };

    public String getD() {
        return d;
    }
    public void setD(String d) {
        this.d = d;
    }
    public String getH() {
        return h;
    }
    public void setH(String h) {
        this.h = h;
    }
    public String getM() {
        return m;
    }
    public void setM(String m) {
        this.m = m;
    }
    public String getM1() {
        return m1;
    }
    public void setM1(String m1) {
        this.m1 = m1;
    }
    public String getM2() {
        return m2;
    }
    public void setM2(String m2) {
        this.m2 = m2;
    }
    public String getM3() {
        return m3;
    }
    public void setM3(String m3) {
        this.m3 = m3;
    }
    public String getM4() {
        return m4;
    }
    public void setM4(String m4) {
        this.m4 = m4;
    }
    public String getM5() {
        return m5;
    }
    public void setM5(String m5) {
        this.m5 = m5;
    }
    public String getR() {
        return r;
    }
    public void setR(String r) {
        this.r = r;
    }
    public String getLd() {
        return ld;
    }
    public void setLd(String ld) {
        this.ld = ld;
    }

    @Override
    public String toString() {
        return "Dic{" + "d='" + d + '\'' + ", h='" + h + '\'' + ", m='" + m + '\'' + ", m1='" + m1 + '\'' +
                ", m2='" + m2 + '\'' + ", m3='" + m3 + '\'' + ", m4='" + m4 + '\'' + ", m5='" + m5 + '\'' +
                ", r='" + r + '\'' + ", ld='" + ld + '\'' + '}';
    }

}
