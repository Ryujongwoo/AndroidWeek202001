package com.example.administrator.jsontest2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.gson.Gson;

import java.io.InputStreamReader;

public class Main3Activity extends AppCompatActivity {

    TextView tv1, tv2, tv3, tv4, tv5, tv6;
    Data data;
    Dic[] dic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        tv1 = findViewById(R.id.tv1);
        tv2 = findViewById(R.id.tv2);
        tv3 = findViewById(R.id.tv3);
        tv4 = findViewById(R.id.tv4);
        tv5 = findViewById(R.id.tv5);
        tv6 = findViewById(R.id.tv6);
//      MainActivity에서 넘어오는 사자성어를 받는다.
        Intent intent = getIntent();
        data = intent.getParcelableExtra("data");
//      한자사전을 받는다.
        Gson gson = new Gson();
        InputStreamReader reader =
                new InputStreamReader(getResources().openRawResource(R.raw.dic));
        dic = gson.fromJson(reader, Dic[].class);
//      위젯에 내용을 채운다.
        tv1.setText(data.getH() + "(" + data.getK() + ")");
//      사자성어의 위치를 넘겨서 위젯에 넣어줄 내용을 얻어온다.
        tv2.setText(fillDic(0));
        tv3.setText(fillDic(1));
        tv4.setText(fillDic(2));
        tv5.setText(fillDic(3));
        tv6.setText(data.getT());
    }

//  사자성어의 각 글자에 대한 음과 뜻을 얻어오는 메소드
    private String fillDic(int position) {
        String str = "";
        for(int i=0 ; i<dic.length ; i++) {
            if(data.getH().substring(position, position + 1).equals(dic[i].getH())) {
                str = dic[i].getH() + " : " + dic[i].getM() + " " + dic[i].getM1() + "(" + dic[i].getD() + ")";
                break;
            }
        }
        return str;
    }

    public void goBack(View view) {
        finish();
    }

}
