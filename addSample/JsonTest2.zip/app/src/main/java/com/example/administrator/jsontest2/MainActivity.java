package com.example.administrator.jsontest2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

//  JSON 파일을 일어올 때 사용하는 외부 라이브러리
import com.google.gson.Gson;

import java.io.InputStreamReader;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<String> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.listView);
//      JSON 파일의 내용을 읽기 위해 Gson 외부 라이브러리 객체를 생성한다.
        Gson gson = new Gson();
//      ======================================================================================================
//      사자성어
//      사자성어가 저장된 res 폴더 아래의 raw 폴더에 저장된 JSON 파일을 InputStreamReader 객체로 읽어들인다.
//      getResources() : res 폴더의 내용을 읽어들인다.
//      openRawResource() : 메소드는 res 폴더 아래의 raw 폴더를 열어서 인수로 지정된 파일을 읽는다.
        InputStreamReader reader =
                new InputStreamReader(getResources().openRawResource(R.raw.data));
//      Gson 객체를 사용해 InputStreamReader 객체의 내용을 읽어서 사자성어 정보를 기억할 클래스(Data)에
//      저장시킨다.
//      JSON 파일에서 읽어온 key와 동일한 이름을 가지는 Data 클래스의 멤버 변수에 값을 자동으로 넣어준다.
        final Data[] data = gson.fromJson(reader, Data[].class);
//      Log.e("사자성어 ", data.length + "개 읽음");
//      ListView에 사용할 데이터를 준비한다.
        for(int i=0 ; i<data.length ; i++) {
            list.add(i + 1 + ". " + data[i].getH() + "(" + data[i].getK() + ")");
//          Log.e("사자성어 ", list.get(i));
        }
//      ======================================================================================================
//      한자검정
        /*
        InputStreamReader reader =
                new InputStreamReader(getResources().openRawResource(R.raw.dic));
        final Dic[] data = gson.fromJson(reader, Dic[].class);
        for(int i=0 ; i<data.length ; i++) {
            list.add(i + 1 + ". " + data[i].getD() + "-" + data[i].getH() + "(" + data[i].getM() +
                    " " + data[i].getM1() + ")");
        }
        */
//      ======================================================================================================
//      Adapter를 만들어 ListView에 올려준다.
        ArrayAdapter<String> adapter =
                new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);
//      ======================================================================================================
//      ListView에 setOnItemClickListener를 구현해서 ListView가 터치되면 실행할 내용을 만든다.
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//              ListView가 터치되었으면 새 액티비티를 띄우고 새 액티비티에 띄울 Intent로 데이터를 넘겨준다.
//              Intent intent = new Intent(getApplicationContext(), Main2Activity.class);
                Intent intent = new Intent(getApplicationContext(), Main3Activity.class);
                intent.putExtra("data", data[i]);
                startActivity(intent);
            }
        });
    }
}










