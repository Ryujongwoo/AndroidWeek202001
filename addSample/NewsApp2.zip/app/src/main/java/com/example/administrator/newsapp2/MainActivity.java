package com.example.administrator.newsapp2;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

//  org.simpleframework:simple-xml:2.7.1 라이브러리를 추가한다.
//  읽어올 XML 파일의 구조를 참고해 클래스(Rss, Channel, Item)를 만든다.
public class MainActivity extends AppCompatActivity {

    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = findViewById(R.id.tv);
        String urlAddr = "http://rss.hankyung.com/new/news_main.xml";
        new NewsTask().execute(urlAddr);
    }

    class NewsTask extends AsyncTask<String, Void, Void> {
//      XML 파일의 최상위 클래스 객체를 선언한다.
        Rss rss = new Rss();
        @Override
        protected Void doInBackground(String... strings) {
//          Log.e("url ", strings[0]);
            try {
//              파싱할 XML 파일의 주소를 받는다.
                URL url = new URL(strings[0]);
//              XML 파일을 읽어올 InputStream 객체를 만들고 읽어들인다.
                InputStream inputStream = url.openStream();
//              파싱을 하기 위해 org.simpleframework:simple-xml:2.7.1 라이브러리 객체를 만든다.
                Serializer serializer = new Persister();
//              읽어들인 XML 파일을 파싱한다.
                rss = serializer.read(Rss.class, inputStream);
                Log.e("rss ", rss.getChannel().toString());
                Log.e("rss ", rss.getVersion().toString());
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            tv.setText(rss.getChannel().getTitle() + "\n");
            for(Item item : rss.getChannel().getItem()) {
                tv.append(item.getTitle() + "\n");
            }
        }
    }

}
