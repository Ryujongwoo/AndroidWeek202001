package com.example.administrator.newsapp2;

//  <channel>
//      <title> ~ </title>
//      <link> ~ </link>
//      <language> ~ </language>
//      <copyright> ~ </copyright>
//      <pubDate> ~ </pubDate>
//      <lastBuildDate> ~ </lastBuildDate>
//      <description> ~ </description>
//      <image> ~ </image>
//      <item>
//          ...
//      </item>
//  </channel>

import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

import java.util.ArrayList;
import java.util.List;

@Root
public class Channel {

//  가져올 데이터가 없는(null인) 태그는 @Element(required = false)라고 적어준다.
    @Element
    String title;
    @Element
    String link;
    @Element
    String language;
    @Element
    String copyright;
    @Element
    String pubDate;
    @Element
    String lastBuildDate;
    @Element
    String description;
    @Element
    Image image;
//  목록을 기억하는 멤버에는 @ElementList(inline = true)를 붙여준다. 만약 에러가 발생된다면 @ElementList 어노테이션
//  속성에 entry = "result"를 추가한다. => @ElementList(entry = "result", inline = true)
    @ElementList(inline = true)
    List<Item> item;

    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getLink() {
        return link;
    }
    public void setLink(String link) {
        this.link = link;
    }
    public String getLanguage() {
        return language;
    }
    public void setLanguage(String language) {
        this.language = language;
    }
    public String getCopyright() {
        return copyright;
    }
    public void setCopyright(String copyright) {
        this.copyright = copyright;
    }
    public String getPubDate() {
        return pubDate;
    }
    public void setPubDate(String pubDate) {
        this.pubDate = pubDate;
    }
    public String getLastBuildDate() {
        return lastBuildDate;
    }
    public void setLastBuildDate(String lastBuildDate) {
        this.lastBuildDate = lastBuildDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Image getImage() {
        return image;
    }

    public void setImage(Image image) {
        this.image = image;
    }

    public List<Item> getItem() {
        return item;
    }
    public void setItem(List<Item> item) {
        this.item = item;
    }

    @Override
    public String toString() {
        return "Channel{" +
                "title='" + title + '\'' +
                ", link='" + link + '\'' +
                ", language='" + language + '\'' +
                ", copyright='" + copyright + '\'' +
                ", pubDate='" + pubDate + '\'' +
                ", lastBuildDate='" + lastBuildDate + '\'' +
                ", description='" + description + '\'' +
                ", image=" + image +
                ", item=" + item +
                '}';
    }

}











