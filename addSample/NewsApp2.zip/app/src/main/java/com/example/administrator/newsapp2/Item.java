package com.example.administrator.newsapp2;

//  <item>
//      <title> ~  </title>
//      <link> ~ </link>
//      <description> ~ </description>
//      <image> ~ </image>
//      <author> ~ </author>
//      <pubDate> ~ </pubDate>
//  </item>

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root
public class Item {

    @Element
    String title;
    @Element
    String link;
    @Element
    String description;
    @Element(required = false)
    String image;
    @Element(required = false)
    String author;
    @Element
    String pubDate;

    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getLink() {
        return link;
    }
    public void setLink(String link) {
        this.link = link;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getImage() {
        return image;
    }
    public void setImage(String image) {
        this.image = image;
    }
    public String getAuthor() {
        return author;
    }
    public void setAuthor(String author) {
        this.author = author;
    }
    public String getPubDate() {
        return pubDate;
    }
    public void setPubDate(String pubDate) {
        this.pubDate = pubDate;
    }

}
