package com.example.administrator.newsapp2;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root
public class Image {

    @Element
    String title;
    @Element
    String url;
    @Element
    String link;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    @Override
    public String toString() {
        return "Image{" +
                "title='" + title + '\'' +
                ", url='" + url + '\'' +
                ", link='" + link + '\'' +
                '}';
    }

}
