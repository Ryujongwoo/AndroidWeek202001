package com.example.administrator.newsapp2;

import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

//  한국 경제신문 rss(http://rss.hankyung.com/new/news_main.xml) XML 파일의 rss 태그를 구현한 클래스
//  org.simpleframework:simple-xml:2.7.1 라이브러리를 추가하면 Root, Element, Attribute 어노테이션을 사용할
//  수 있다.
//  @Root : 최상위 태그를 의미한다.
//  @Element : 최상위 태그 내부에 포함된 한번만 태그를 의미한다.
//  @ElementList : 최상위 태그 내부에 포함된 여러번 나오는 태그를 의미한다.
//  @Attribute : 태그의 속성을 의미한다.

//  <rss version="2.0">
//      ...
//  </rss>
@Root
public class Rss {

    @Element
    Channel channel;
    @Attribute
    String version;

    public Channel getChannel() {
        return channel;
    }
    public void setChannel(Channel channel) {
        this.channel = channel;
    }
    public String getVersion() {
        return version;
    }
    public void setVersion(String version) {
        this.version = version;
    }

}
