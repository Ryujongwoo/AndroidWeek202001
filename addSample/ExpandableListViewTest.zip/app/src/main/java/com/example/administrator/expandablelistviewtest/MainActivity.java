package com.example.administrator.expandablelistviewtest;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ExpandableListView eListView;

    ArrayList<String> mGroupList = null;                // 대항목
    ArrayList<ArrayList<String>> mChildList = null;     // 소항목의 목록
    ArrayList<String> mChildListContent1 = null;        // 첫 번째 대항목의 자식 리스트
    ArrayList<String> mChildListContent2 = null;        // 두 번째 대항목의 자식 리스트
    ArrayList<String> mChildListContent3 = null;        // 세 번째 대항목의 자식 리스트
    ArrayList<String> mChildListContent4 = null;        // 네 번째 대항목의 자식 리스트

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        eListView = findViewById(R.id.eListView);

        mGroupList = new ArrayList<>();
        mGroupList.add("대항목 1");
        mGroupList.add("대항목 2");
        mGroupList.add("대항목 3");
        mGroupList.add("대항목 4");

        mChildList = new ArrayList<>();

        mChildListContent1 = new ArrayList<>();
        mChildListContent1.add("소항목 1-1");
        mChildListContent1.add("소항목 1-2");
        mChildListContent1.add("소항목 1-3");
        mChildList.add(mChildListContent1);

        mChildListContent2 = new ArrayList<>();
        mChildListContent2.add("소항목 2-1");
        mChildListContent2.add("소항목 2-2");
        mChildList.add(mChildListContent2);

        mChildListContent3 = new ArrayList<>();
        mChildListContent3.add("소항목 3-1");
        mChildListContent3.add("소항목 3-2");
        mChildListContent3.add("소항목 3-3");
        mChildListContent3.add("소항목 3-4");
        mChildList.add(mChildListContent3);

        mChildListContent4 = new ArrayList<>();
        mChildListContent4.add("소항목 4-1");
        mChildListContent4.add("소항목 4-2");
        mChildListContent4.add("소항목 4-3");
        mChildList.add(mChildListContent4);

//      ExpandableListView에 Adapter 객체를 만들어 올려준다.
        BaseExpandableListAdapter adapter =
                new BaseExpandableAdapter(getApplicationContext(), mGroupList, mChildList);
        eListView.setAdapter(adapter);

//      ExpandableListView에서 자식이 클릭되면 실행될 Listener를 등록한다.
        eListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView expandableListView, View view, int groupPosition,
                                        int childPosition, long l) {
                Toast.makeText(getApplicationContext(), mChildList.get(groupPosition).get(childPosition),
                        Toast.LENGTH_SHORT).show();
                return false;
            }
        });

//      ExpandableListView에서 부모가 클릭되면 실행될 Listener를 등록한다.
        eListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView expandableListView, View view, int groupPosition,
                                        long l) {
                Toast.makeText(getApplicationContext(), mGroupList.get(groupPosition), Toast.LENGTH_SHORT).show();
                return false;
            }
        });

//      ExpandableListView에서 부모가 확장될 때 실행될 Listener를 등록한다.
        eListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            @Override
            public void onGroupExpand(int groupPosition) {
//              선택된 그룹이 확장될 때 나머지 모든 그룹을 접는다.
                for(int i=0 ; i<mGroupList.size() ; i++) {
                    if(i != groupPosition) {
                        eListView.collapseGroup(i);
                    }
                }
            }
        });
    }

//  BaseExpandableListAdapter 클래스를 상속받아 대항목 뷰와 소항목 뷰를 따로 만들어서 가지고 있다가
//  ExpandableListView에 표시하는 Adapter를 만든다.
    public class BaseExpandableAdapter extends BaseExpandableListAdapter {

//      생성자의 인수로 넘어오는 대항목과 소항목의 목록을 저장할 멤버를 만든다.
        ArrayList<String> groupList = null;
        ArrayList<ArrayList<String>> childList = null;

//      ExpandableListView를 만들기 위한 재료를 선언한다.
        LayoutInflater inflater = null;             // 레이아웃 전개
        ViewHolder viewHolder = null;               // 뷰
//      레이아웃을 전개했을 때 View의 목록으로 사용할 클래스를 선언한다.
        class ViewHolder {
            ImageView iv;
            TextView tv_group;
            TextView tv_child;
        }

        public BaseExpandableAdapter(Context context, ArrayList<String> groupList,
                                     ArrayList<ArrayList<String>> childList) {
            this.groupList = groupList;
            this.childList = childList;
            this.inflater = getLayoutInflater();
        }

//      그룹의 크기를 리턴한다.
//      return 0 => return groupList.size()
        @Override
        public int getGroupCount() {
            return groupList.size();
        }

//      groupPosition 번째에 해당되는 자식의 크기를 리턴한다.
//      return 0 => return childList.get(groupPosition).size()
        @Override
        public int getChildrenCount(int groupPosition) {
            return childList.get(groupPosition).size();
        }

//      groupPosition 번째 그룹 이름을 리턴한다.
//      return null => return groupList.get(groupPosition)
        @Override
        public String getGroup(int groupPosition) {
            return groupList.get(groupPosition);
        }

//      groupPosition 번째 그룹의 자식 뷰를 리턴한다.
//      return null => childList.get(groupPosition).get(childPosition)
        @Override
        public String getChild(int groupPosition, int childPosition) {
            return childList.get(groupPosition).get(childPosition);
        }

//      groupPosition 번째 그룹의 ID(위치)를 반환한다.
//      return 0 => return groupPosition
        @Override
        public long getGroupId(int groupPosition) {
            return groupPosition;
        }

//      groupPosition 번째 그룹의 자식 뷰의 ID(위치)를 반환한다.
//      return 0 => return childPosition
        @Override
        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }

//      return false => return true
        @Override
        public boolean hasStableIds() { return true; }

//      그룹 뷰 각각 행(ROW)을 만든다.
        @Override
        public View getGroupView(int groupPosition, boolean isExpanded, View contentView, ViewGroup parent) {
            View view = contentView;
            if(view == null) {
                viewHolder = new ViewHolder();
                view = inflater.inflate(R.layout.listrow, parent, false);
                viewHolder.tv_group = view.findViewById(R.id.tv_group);
                viewHolder.iv = view.findViewById(R.id.iv);
                view.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) view.getTag();
            }
//          그룹을 펼칠때와 닫을때 아이콘을 변경한다.
            if(isExpanded) {
                viewHolder.iv.setBackgroundColor(Color.CYAN);
            } else {
                viewHolder.iv.setBackgroundColor(Color.WHITE);
            }
            viewHolder.tv_group.setText(getGroup(groupPosition));
            return view;
        }

//      자식 뷰 각각 행(ROW)을 만든다.
        @Override
        public View getChildView(int groupPosition, int childPosition, boolean isLastChild,
                                 View convertView, ViewGroup parent) {
            View view = convertView;
            if(view == null) {
                viewHolder = new ViewHolder();
                view = inflater.inflate(R.layout.listrow, null);
                viewHolder.tv_child = view.findViewById(R.id.tv_child);
                view.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) view.getTag();
            }
            viewHolder.tv_child.setText(getChild(groupPosition, childPosition));
            return view;
        }

//      return false => return true
        @Override
        public boolean isChildSelectable(int groupPosition, int childPosition) { return true; }
    }

}
