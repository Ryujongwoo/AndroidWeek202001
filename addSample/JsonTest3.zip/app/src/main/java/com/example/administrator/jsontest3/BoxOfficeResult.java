package com.example.administrator.jsontest3;

import java.util.Arrays;

//  박스 오피스 종류별 정보를 기억하는 클래스
//  "boxofficeType" : "일별 박스오피스"
//  "showRange" : "20180530~20180530"
//  "DailyBoxOfficeList" : [] => 박스 오피스 영화 10건의 정보가 저장된 JSON 배열
public class BoxOfficeResult {

    String boxofficeType;   // 박스 오피스 종류
    String showRange;       // 박스 오피스 조회 일자
    DailyBoxOfficeList[] dailyBoxOfficeList;       // 박스 오피스 결과가 저장될 배열

    public String getBoxofficeType() {
        return boxofficeType;
    }
    public void setBoxofficeType(String boxofficeType) {
        this.boxofficeType = boxofficeType;
    }
    public String getShowRange() {
        return showRange;
    }
    public void setShowRange(String showRange) {
        this.showRange = showRange;
    }
    public DailyBoxOfficeList[] getDailyBoxOfficeList() {
        return dailyBoxOfficeList;
    }
    public void setDailyBoxOfficeLists(DailyBoxOfficeList[] dailyBoxOfficeList) {
        this.dailyBoxOfficeList = dailyBoxOfficeList;
    }

}
