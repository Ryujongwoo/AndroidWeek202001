package com.example.administrator.jsontest3;

import java.util.Arrays;

//  박스 오피스 종류별 정보를 기억하는 클래스
//  "boxofficeType" : "일별 박스오피스"
//  "showRange" : "20180530~20180530"
//  "yearWeekTime" : "201821"
//  "WeeklyBoxOfficeList" : [] => 박스 오피스 영화 10건의 정보가 저장된 JSON 배열
public class BoxOfficeResult2 {

    String boxofficeType;   // 박스 오피스 종류
    String showRange;       // 박스 오피스 조회 일자
    String yearWeekTime;    // 조회 일자에 해당하는 연도와 주차(YYYYIW)
    DailyBoxOfficeList[] weeklyBoxOfficeList;       // 박스 오피스 결과가 저장될 배열

    public String getBoxofficeType() {
        return boxofficeType;
    }
    public void setBoxofficeType(String boxofficeType) {
        this.boxofficeType = boxofficeType;
    }
    public String getShowRange() {
        return showRange;
    }
    public void setShowRange(String showRange) {
        this.showRange = showRange;
    }
    public String getYearWeekTime() {
        return yearWeekTime;
    }
    public void setYearWeekTime(String yearWeekTime) {
        this.yearWeekTime = yearWeekTime;
    }
    public DailyBoxOfficeList[] getWeeklyBoxOfficeList() {
        return weeklyBoxOfficeList;
    }
    public void setWeeklyBoxOfficeList(DailyBoxOfficeList[] weeklyBoxOfficeList) {
        this.weeklyBoxOfficeList = weeklyBoxOfficeList;
    }

}
