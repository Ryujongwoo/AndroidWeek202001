package com.example.administrator.jsontest3;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.gson.Gson;

import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<String> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.listView);

//      발급 받은 OPEN API key를 저장한다.
        String key = "4028bc13e12484c3ab4e79fab4363f63";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
//      ========================================================================================================
        /*
//      전일 기준 일별 오피스 박스
//      어제 날짜를 만든다.
//      Date date = new Date();
//      date.setDate(date.getDate() - 1);
//      Log.e("어제 날짜 ", sdf.format(date));
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -1);
//      Log.e("어제 날짜 ", sdf.format(calendar.getTime()));
//      일별 오피스 박스 API를 얻어올 위치의 url을 만든다.
        String url =
                "http://www.kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchDailyBoxOfficeList.json";
        url += "?key=" + key + "&targetDt=" + sdf.format(calendar.getTime());
        */
//      ========================================================================================================
//      주말 오피스 박스
//      일주일전 날짜를 만든다.
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -7);
//      주간 오피스 박스 API를 얻어올 위치의 url을 만든다.
        String url =
                "http://www.kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchWeeklyBoxOfficeList.json";
        url += "?key=" + key + "&targetDt=" + sdf.format(calendar.getTime());
//      ========================================================================================================
//      Log.e("API url ", url);
        new BoxOfficeTack().execute(url);
    }

//  JSON 파일을 인터넷에 접속해 얻어오는 내부 클래스를 AsyncTask 클래스를 상속받아 만든다.
//  AsyncTask 클래스의 Void는 첫 문자가 대문자인것에 주의한다.
    class BoxOfficeTack extends AsyncTask<String, Void, Void> {
//      AsyncTask 클래스를 상속받은 객체에서 execute() 메소드가 실행될 때 자동으로 실행되는 메소드로 백 그라운드
//      작업을 한다.
        @Override
        protected Void doInBackground(String... strings) {
//          Log.e("doInBackground() ", strings[0].toString());
            try {
//              JSON 파일을 읽어올 인터넷 주소가 저장된 URL 객체를 만든다.
                URL url = new URL(strings[0]);
//              url로 접근해서 JSON 파일을 읽어 InputStreamReader 객체에 저장한다.
                InputStreamReader reader = new InputStreamReader(url.openStream(), "UTF-8");
//              Gson 객체를 이용해 인터넷에 접속해 얻어온 JSON 파일을 읽어들인다.
                Gson gson = new Gson();
//              BoxOffice boxOffice = gson.fromJson(reader, BoxOffice.class);   // 일별
                BoxOffice2 boxOffice = gson.fromJson(reader, BoxOffice2.class); // 주말
//              Log.e("boxOffice ", boxOffice.toString());
//              ListView에 넣어줄 데이터를 준비한다.
                list.add(boxOffice.getBoxOfficeResult().getBoxofficeType());    // 박스 오피스 종류
                list.add(boxOffice.getBoxOfficeResult().getShowRange());        // 박스 오피스 조회 일자
//              아래의 박스 오피스 연도와 주차는 주말 오피스 박스일 경우만 적는다.
                String s = boxOffice.getBoxOfficeResult().getYearWeekTime();
                list.add(s.substring(0, 4) + "년 " + s.substring(4) + "주");
//              영화 목록 개수 만큼 반복하며 ArrayList에 데이터를 넣어준다.
//              for(DailyBoxOfficeList d : boxOffice.getBoxOfficeResult().getDailyBoxOfficeList()) {    // 일별
                for(DailyBoxOfficeList d : boxOffice.getBoxOfficeResult().getWeeklyBoxOfficeList()) {   // 주말
                    list.add(d.getRank() + ". " + d.getMovieNm());
                }
//              for(String str : list) {
//                  Log.e("Office Box ", str);
//              }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

//      doInBackground() 메소드가 실행되고 난 후 자동으로 실행되는 onPostExecute() 메소드를 override 하고
//      Adapter를 만들어 listView에 올려준다.
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            ArrayAdapter<String> adapter =
                    new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, list);
            listView.setAdapter(adapter);
        }
    }


}
