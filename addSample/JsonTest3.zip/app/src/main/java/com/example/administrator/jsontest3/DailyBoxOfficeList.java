package com.example.administrator.jsontest3;

//  박스 오피스 영화 1건의 정보를 기억하는 클래스
public class DailyBoxOfficeList {

    String rnum;            // 순번
    String rank;            // 해당 일자의 순위
    String rankInten;       // 전일 대비 순위의 증감분
    String rankOldAndNew;   // 신규 진입 여부, OLD : 기존 , NEW : 신규
    String movieCd;         // 영화의 대표 코드
    String movieNm;         // 영화명(국문)
    String openDt;          // 개봉일
    String salesAmt;        // 해당 일의 매출액
    String salesShare;      // 해당 일자 상영작의 매출 총액 대비 해당 영화의 매출 비율
    String salesInten;      // 전일 대비 매출액 증감분
    String salesChange;     // 전일 대비 매출액 증감 비율
    String salesAcc;        // 누적 매출액
    String audiCnt;         // 해당 일의 관객수
    String audiInten;       // 전일 대비 관객수 증감분
    String audiChange;      // 전일 대비 관객수 증감 비율
    String audiAcc;         // 누적 관객수
    String scrnCnt;         // 해당 일자에 상영한 스크린수
    String showCnt;         // 해당 일자에 상영된 횟수

    public String getRnum() {
        return rnum;
    }
    public void setRnum(String rnum) {
        this.rnum = rnum;
    }
    public String getRank() {
        return rank;
    }
    public void setRank(String rank) {
        this.rank = rank;
    }
    public String getRankInten() {
        return rankInten;
    }
    public void setRankInten(String rankInten) {
        this.rankInten = rankInten;
    }
    public String getRankOldAndNew() {
        return rankOldAndNew;
    }
    public void setRankOldAndNew(String rankOldAndNew) {
        this.rankOldAndNew = rankOldAndNew;
    }
    public String getMovieCd() {
        return movieCd;
    }
    public void setMovieCd(String movieCd) {
        this.movieCd = movieCd;
    }
    public String getMovieNm() {
        return movieNm;
    }
    public void setMovieNm(String movieNm) {
        this.movieNm = movieNm;
    }
    public String getOpenDt() {
        return openDt;
    }
    public void setOpenDt(String openDt) {
        this.openDt = openDt;
    }
    public String getSalesAmt() {
        return salesAmt;
    }
    public void setSalesAmt(String salesAmt) {
        this.salesAmt = salesAmt;
    }
    public String getSalesShare() {
        return salesShare;
    }
    public void setSalesShare(String salesShare) {
        this.salesShare = salesShare;
    }
    public String getSalesInten() {
        return salesInten;
    }
    public void setSalesInten(String salesInten) {
        this.salesInten = salesInten;
    }
    public String getSalesChange() {
        return salesChange;
    }
    public void setSalesChange(String salesChange) {
        this.salesChange = salesChange;
    }
    public String getSalesAcc() {
        return salesAcc;
    }
    public void setSalesAcc(String salesAcc) {
        this.salesAcc = salesAcc;
    }
    public String getAudiCnt() {
        return audiCnt;
    }
    public void setAudiCnt(String audiCnt) {
        this.audiCnt = audiCnt;
    }
    public String getAudiInten() {
        return audiInten;
    }
    public void setAudiInten(String audiInten) {
        this.audiInten = audiInten;
    }
    public String getAudiChange() {
        return audiChange;
    }
    public void setAudiChange(String audiChange) {
        this.audiChange = audiChange;
    }
    public String getAudiAcc() {
        return audiAcc;
    }
    public void setAudiAcc(String audiAcc) {
        this.audiAcc = audiAcc;
    }
    public String getScrnCnt() {
        return scrnCnt;
    }
    public void setScrnCnt(String scrnCnt) {
        this.scrnCnt = scrnCnt;
    }
    public String getShowCnt() {
        return showCnt;
    }
    public void setShowCnt(String showCnt) {
        this.showCnt = showCnt;
    }

    @Override
    public String toString() {
        return "DailyBoxOfficeList{" +
                "rnum='" + rnum + '\'' +
                ", rank='" + rank + '\'' +
                ", rankInten='" + rankInten + '\'' +
                ", rankOldAndNew='" + rankOldAndNew + '\'' +
                ", movieCd='" + movieCd + '\'' +
                ", movieNm='" + movieNm + '\'' +
                ", openDt='" + openDt + '\'' +
                ", salesAmt='" + salesAmt + '\'' +
                ", salesShare='" + salesShare + '\'' +
                ", salesInten='" + salesInten + '\'' +
                ", salesChange='" + salesChange + '\'' +
                ", salesAcc='" + salesAcc + '\'' +
                ", audiCnt='" + audiCnt + '\'' +
                ", audiInten='" + audiInten + '\'' +
                ", audiChange='" + audiChange + '\'' +
                ", audiAcc='" + audiAcc + '\'' +
                ", scrnCnt='" + scrnCnt + '\'' +
                ", showCnt='" + showCnt + '\'' +
                '}';
    }

}
