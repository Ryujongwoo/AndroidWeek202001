package com.example.administrator.jsontest3;

//  전체 구조
//  boxOfficeResult : boxofficeType, showRange, DailyBoxOfficeList[]
//  DailyBoxOfficeList : rnum, rank, rankInten, rankOldAndNew, movieCd, movieNm, openDt, salesAmt, salesShare,
//                      salesInten, salesChange, salesAcc, audiCnt, audiInten, audiChange, audiAcc, scrnCnt,
//                      showCnt
//  박스 오피스 전체 정보를 기억하는 클래스
//  읽어들이는 JSON 객체가 복잡해 보이지만 실제로 넘어오는 JSON 객체는 1개이다.
public class BoxOffice2 {

    BoxOfficeResult2 boxOfficeResult;

    public BoxOfficeResult2 getBoxOfficeResult() {
        return boxOfficeResult;
    }
    public void setBoxOfficeResult(BoxOfficeResult2 boxOfficeResult) {
        this.boxOfficeResult = boxOfficeResult;
    }

}
