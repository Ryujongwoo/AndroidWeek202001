package com.example.administrator.xmlparsertest2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.StringReader;

public class MainActivity extends AppCompatActivity {

    TextView tv;
    StringBuffer stringBuffer = new StringBuffer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = findViewById(R.id.tv);

//      파싱할 XML 문서를 만든다.
        stringBuffer.append("<root>");
            stringBuffer.append("<item>");
                stringBuffer.append("<name>");
                     stringBuffer.append("홍길동");
                stringBuffer.append("</name>");
                stringBuffer.append("<age>");
                     stringBuffer.append("20");
                stringBuffer.append("</age>");
            stringBuffer.append("</item>");
            stringBuffer.append("<item>");
                stringBuffer.append("<name>");
                     stringBuffer.append("임꺽정");
                stringBuffer.append("</name>");
                stringBuffer.append("<age>");
                     stringBuffer.append("35");
                stringBuffer.append("</age>");
            stringBuffer.append("</item>");
            stringBuffer.append("<item>");
                stringBuffer.append("<name>");
                     stringBuffer.append("장길산");
                stringBuffer.append("</name>");
                stringBuffer.append("<age>");
                     stringBuffer.append("58");
                stringBuffer.append("</age>");
            stringBuffer.append("</item>");
        stringBuffer.append("</root>");

        tv.setText(getXMLData(stringBuffer.toString()));
    }

//  XML 파싱을 하는 메소드
    private String getXMLData(String xmlData) {
        String result = "";
        try {
//          SAX 파서의 변형으로 이벤트 방식의 파싱을 하는 XmlPullParser 객체를 XmlPullParserFactory 객체를
//          사용해서 만든다.
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            XmlPullParser parser = factory.newPullParser();

//          XmlPullParser 객체로 파싱할 내용을 읽어들인다.
            parser.setInput(new StringReader(xmlData));

//          파싱 작업에 필요한 변수를 만든다.
            String name = "";           // name 태그의 내용을 기억할 변수
            int age = 0;                // age 태그의 내용을 기억할 변수
            String tagName = "";        // 태그 이름을 기억할 변수
            boolean isName = false;     // name 태그가 시작되었나 판단할 때 사용할 변수
            boolean isAge = false;      // age 태그가 시작되었나 판단할 때 사용할 변수

//          파싱을 하기 위해 getEventType() 메소드로 parser에서 최초로 발생되는 이벤트(START_DOCUMENT)
//          타입을 읽는다.
            int eventType = parser.getEventType();
//          Log.e("XML 파일 시작 ", eventType == XmlPullParser.START_DOCUMENT ? "읽기 시작" : "");

//          XML 문서가 끝날 때 까지 반복하며 파싱한다.
            while(eventType != XmlPullParser.END_DOCUMENT) {
//              switch를 이용해 발생된 이벤트 별로 실행할 내용을 만든다.
                switch (eventType) {
                    case XmlPullParser.START_TAG:       // 태그가 작되면 발생되는 이벤트
//                      getName() : 파싱된 태그 이름을 얻어온다.
//                      getText() : 파싱된 태그 사이의 텍스트를 얻어온다.
//                      Log.e("태그 시작 ", "<" + parser.getName() + ">");
                        tagName = parser.getName();
                        switch (tagName.toLowerCase()) {
                            case "name": isName = true; break;
                            case "age": isAge = true; break;
                        }
                        break;
                    case XmlPullParser.END_TAG:         // 태그가 끝나면 발생되는 이벤트
//                      Log.e("태그 끝 ", "</" + parser.getName() + ">");
                        tagName = parser.getName();
                        switch (tagName.toLowerCase()) {
                            case "name": isName = false; break;
                            case "age": isAge = false; break;
//                          item 태그가 종료될 때 마다 item 태그의 데이터를 result에 추가한다.
                            case "item":
                                result += String.format("%s 님은 %d살 입니다.\n", name, age);
                                break;
                        }
                        break;
                    case XmlPullParser.TEXT:            // 태그 사이의 문자열을 만나면 실행되는 이벤트
//                      Log.e("텍스트 ", parser.getText());
                        name = isName ? parser.getText() : name;
                        age = isAge ? Integer.parseInt(parser.getText()) : age;
                        break;
                }

//              다음 XML 문장의 이벤트를 처리하기 위해서 next() 메소드로 parser에서 다음에 발생되는 이벤트
//              타입을 읽는다.
                eventType = parser.next();
            }
//          이곳은 while문이 종료된 다음 실행되므로 마지막 item 태그의 내용만 result에 저장된다.
//          result += String.format("%s 님은 %d살 입니다.\n", name, age);

        } catch (XmlPullParserException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

}










