package com.example.administrator.xmlparsertest4;

/*
<item>
    <title> ~ </title>                  // 제목
    <link> ~ </link>                    // 글이 저장된 경로
    <description> ~ </description>      // 설명
    <bloggername> ~ </bloggername>      // 블로그 이름
    <bloggerlink> ~ </bloggerlink>      // 블로그 주소, http://blog.namver.com/아이디
    <postdate> ~ </postdate>            // 포스팅 날짜
</item>
*/

//  검색어가 포함된 블로그를 찾아서 기억하는 클래스
public class Item {

    String title;
    String link;
//  String description;
//  String bloggername;
//  String bloggerlink;
//  String postdate;

    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getLink() {
        return link;
    }
    public void setLink(String link) {
        this.link = link;
    }

    @Override
    public String toString() {
        return "Item{" + "title='" + title + '\'' + ", link='" + link + '\'' + '}';
    }

}
