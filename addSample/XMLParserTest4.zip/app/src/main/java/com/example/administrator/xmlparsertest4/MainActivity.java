package com.example.administrator.xmlparsertest4;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText et;
    ListView listView;
    String clientId = "6fbo7PXjITAonKdWGcsS";       // 애플리케이션 클라이언트 아이디값
    String clientSecret = "D5dJsSguW2";             // 애플리케이션 클라이언트 시크릿값
    ArrayList<Item> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et = findViewById(R.id.et);
        listView = findViewById(R.id.listView);
    }

    public void searchView(View view) {
//      검색어를 받아서 NULL 또는 공백이 아니면 검색어가 포함된 블로그를 읽어오는 메소드를 실행한다.
        String searchWord = et.getText().toString();
        if(searchWord != null && !searchWord.trim().equals("")) {
//          AsynkTask 클래스를 상속받아 만드는 객체에서 execute() 메소드로 doInBackground() 메소드를 실행한다.
            new SecrchTask().execute(searchWord);
        }
    }

    class SecrchTask extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... strings) {
            try {
//              EditText에 입력된 검색어를 받아서 검색 쿼리 url을 완성한다. naver 제공
                String text = URLEncoder.encode(strings[0], "UTF-8");
                Log.e("text ", text);
//              String apiURL = "https://openapi.naver.com/v1/search/blog?query=" + text;       // json 결과
//              String apiURL = "https://openapi.naver.com/v1/search/blog.xml?query=" + text;   // xml 결과
                String apiURL = "https://openapi.naver.com/v1/search/blog.xml?query=" + text + "&display=50";
                URL url = new URL(apiURL);
//              Log.e("apiURL ", apiURL);
//              HttpURLConnection 클래스 객체로 검색 쿼리 url에 접속해서 GET 방식으로 데이터를 얻어올 수 있도록
//              인증해서 인증된 결과를 responseCode에 저장한다. naver 제공
                HttpURLConnection con = (HttpURLConnection)url.openConnection();
                con.setRequestMethod("GET");
                con.setRequestProperty("X-Naver-Client-Id", clientId);
                con.setRequestProperty("X-Naver-Client-Secret", clientSecret);
                int responseCode = con.getResponseCode();
//              Log.e("responseCode ", responseCode + "");
//              검색 쿼리 url에 접속해서 얻어온 XML 데이터를 파싱할 XmlPullParser 객체를 만든다.
                XmlPullParser parser = XmlPullParserFactory.newInstance().newPullParser();

//              검색 쿼리 url이 정상적으로 호출되었으면 XML 데이터를 읽어 파싱한다.
                if(responseCode == 200) {   // 정상 호출

//                  정상적으로 접속이 되었으므로 XML 데이터를 읽어서 XmlPullParser 객체에 저장한다.
                    parser.setInput(new InputStreamReader(con.getInputStream()));
//                  이전에 읽어온 내용이 ArrayList에 남아있으면 안되므로 모두 지워준다.
                    list.clear();
//                  작업에 필요한 만큼 boolean 변수를 만들어 false로 초기화 시킨다.
                    boolean isItem = false, isTitle = false, isLink = false;
//                  XML 파일에서 읽은 태그 이름을 기억할 변수를 만든다.
                    String tagName = "";
//                  Item 클래스 객체를 선언만 한다. 실제 객체는 <item> 태그를 만나면 생성한다.
                    Item item = null;
//                  XML 파일에서 최초의 태그를 getEventType() 메소드로 읽어들인다. 두번째 태그 부터는 while
//                  블록의 끝에서 next() 메소드로 읽는다.
                    int type = parser.getEventType();
//                  XML 문서의 끝까지 반복하며 태그를 읽어 적당한 작업을 실행한다.
                    while(type != XmlPullParser.END_DOCUMENT) {
                        switch (type) {
                            case XmlPullParser.START_TAG:
                                tagName = parser.getName();
//                              Log.e(" ",  "<" + parser.getName() + ">");
                                switch (tagName.toLowerCase()) {
                                    case "item":
//                                      item 태그가 시작되면 Item 클래스의 객체를 만든다.
                                        item = new Item();
                                        isItem = true;      // item 태그가 시작됨을 알림
                                        break;
                                    case "title":
                                        isTitle = true;     // title 태그가 시작됨을 알림
                                        break;
                                    case "link":
                                        isLink = true;      // link 태그가 시작됨을 알림
                                        break;
                                }
                                break;
                            case XmlPullParser.END_TAG:
                                tagName = parser.getName();
//                              Log.e(" ",  "</" + parser.getName() + ">");
                                switch (tagName.toLowerCase()) {
                                    case "item":
//                                      item 태그가 종료되면 Item 클래스의 객체 ArrayList에 저장한다.
                                        list.add(item);
                                        isItem = false;     // item 태그가 종료됨을 알림
                                        break;
                                    case "title":
                                        isTitle = false;    // title 태그가 종료됨을 알림
                                        break;
                                    case "link":
                                        isLink = false;     // link 태그가 종료됨을 알림
                                        break;
                                }
                                break;
                            case XmlPullParser.TEXT:
//                              Log.e(" ",  parser.getText() + " ");
//                              item 태그와 title 태그가 시작되었으면 Item 클래스 객체에 title을 저장한다.
                                if(isItem && isTitle) {
                                    item.setTitle(parser.getText());
                                }
//                              item 태그와 link 태그가 시작되었으면 Item 클래스 객체에 link를 저장한다.
                                if(isItem && isLink) {
                                    item.setLink(parser.getText());
                                }
                                break;
                        }
                        type = parser.next();
                    }
//                  for(Item i : list) {
//                      Log.e("data ", i + "");
//                  }

                } else {    // 에러 발생
                    Item item = new Item();
                    item.setTitle("에러발생");
                    list.add(item);
//                  Log.e("에러발생 ", "에러");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
//          출력할 내용을 Adapter로 만들어 ListView에 올려준다.
            ArrayList<String> data = new ArrayList<>();
            for(Item item : list) {
                data.add(item.getTitle());
//              data.add(item.getLink());
            }
            ArrayAdapter<String> adapter =
                    new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, data);
            listView.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        }
    }

}
















