package com.example.administrator.navermaptest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.nhn.android.maps.NMapActivity;
import com.nhn.android.maps.NMapController;
import com.nhn.android.maps.NMapView;
import com.nhn.android.maps.maplib.NGeoPoint;

//  안드로이드 스튜디오에서 프로젝트를 생성할 때 패키지명은 나중에 애플리케이션 등록설정의 안드로이드 패키지명과
//  반드시 일치하도록 주의 합니다.
//  네이버 지도 라이브러리를 설치한다.
//  Gradel Scripts의 build.gradle (Moduel:app) dependencies 설정에 아래 라인을 추가합니다.
//  compile 'com.naver.maps.open:naver-map-api:2.1.2@aar'
//  compile을 implementation으로 변경하라는 메시지가 출력되므로 변경해 준다.
//  네이버 지도를 사용하는 앱은 NMapActivity 클래스를 상속받아 만든다.
public class MainActivity extends NMapActivity {

//  네이버 지도 화면 View 객체를 선언한다.
//  NMapView 클래스는 안드로이드 ViewGroup 클래스를 상속받은 클래스로서 지도 데이터를 화면에 표시합니다.
//  본 클래스에서 관리하는 지도 데이터는 지도 이미지 이외에도 지도 위에 표시되는 오버레이 객체를 포함합니다.
//  또한 내부적으로 터치 및 키보드 이벤트를 처리하며 오버레이 객체에도 이벤트가 전달됩니다.
//  본 클래스는 반드시 NMapActivity 클래스를 상속받은 Activity 클래스에서 생성되어야 합니다.
    private NMapView mMapView;
//  애플리케이션 클라이언트 아이디 값을 설정한다.
    private final String CLIENT_ID = "RSMVfdWdBOCARGxYOn3Z";
//  NMapController 클래스는 지도의 상태를 변경하고 컨트롤하기 위한 클래스입니다.
//  NMapView 클래스 생성 시 내부적으로 생성되며 NMapView 클래스의 getMapController() 메서드를 통해서 접근합니다.
//  지도 중심 및 축척 레벨 변경과 지도 확대, 축소, 패닝 등 다양한 기능을 수행합니다.
    NMapController mMapController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mMapView = new NMapView(this);

//      지도 중심 및 축척 레벨 변경과 지도 확대, 축소, 패닝 등 다양한 기능을 수행하기 위해서 getMapController()
//      메소드로 NMapView 클래스 객체에 접근한다.
        mMapController = mMapView.getMapController();
//      NGeoPoint 클래스는 지도 상의 경위도 좌표를 나타내는 클래스로 new NGeoPoint(경도, 위도) 생성자를 이용해
//      객체를 생성한 후 NMapController 클래스의 setMapCenter() 메소드의 첫 번째 인수로 지도의 중심을 지정한다.
//      setMapCenter(지도의 중심 좌표, 축적 레벨)
        mMapController.setMapCenter(new NGeoPoint(127.1086446, 37.7993698), 10);
//      setBuiltInZoomControls() 메소드로 내장된 줌 컨트롤의 활성화 여부를 설정한다
        mMapView.setBuiltInZoomControls(true, null);
        setContentView(mMapView);

        mMapView.setClientId(CLIENT_ID);        // 클라이언트 아이디 값 설정
        mMapView.setClickable(true);
        mMapView.setEnabled(true);
        mMapView.setFocusable(true);
        mMapView.setFocusableInTouchMode(true);
        mMapView.requestFocus();

    }
}
