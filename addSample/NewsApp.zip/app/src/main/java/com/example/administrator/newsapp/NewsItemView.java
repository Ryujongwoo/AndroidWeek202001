package com.example.administrator.newsapp;

import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

//  ListView에 올려질 레이아웃을 전개하고 데이터를 넣어주는 클래스
//  전개할 레이아웃의 메인 레이아웃이 LinearLayout 이므로 LinearLayout를 상속받아 만든다.
public class NewsItemView extends LinearLayout {

    ImageView imageView;
    TextView titleTv, descriptionTv;

    public NewsItemView(Context context, NewsItem item) {
        super(context);
//      생성자에서 레이아웃을 읽어 전개한다.
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.newsitem, this, true);
//      전개된 레이아웃에서 위젯을 얻어온다.
        imageView = findViewById(R.id.imageView);
        titleTv = findViewById(R.id.titleTv);
        descriptionTv = findViewById(R.id.descriptionTv);
//      위젯에 데이터를 넣어준다.
        if(item.getImage() == null) {
            imageView.setImageResource(R.drawable.noimage);
        } else {
            Picasso.get().load(item.getImage()).into(imageView);
        }
        titleTv.setText(Html.fromHtml(item.getTitle()));
        descriptionTv.setText(Html.fromHtml(item.getDescription().substring(0,50)));
    }
}









