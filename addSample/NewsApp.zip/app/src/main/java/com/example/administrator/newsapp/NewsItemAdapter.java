package com.example.administrator.newsapp;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import java.util.ArrayList;

//  BaseAdapter 클래스를 상속받아 ListView에 레이아웃을 전개할 Adapter 클래스를 만든다.
public class NewsItemAdapter extends BaseAdapter{

    Context context;
    ArrayList<NewsItem> list;

    public NewsItemAdapter(Context context, ArrayList<NewsItem> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        return new NewsItemView(context, list.get(i));
    }

}
