package com.example.administrator.newsapp;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Spinner spinner;
    ListView listView;
    ArrayList<NewsItem> list = new ArrayList<>();

//  뉴스를 얻어올 언론사 이름, RSS 주소, 인코딩 방식을 설정한다.
    String news[] = {"한국경제","동아일보","매일경제","조선일보"};
    String urlAddr[] = {"http://rss.hankyung.com/new/news_main.xml",
            "http://rss.donga.com/sportsdonga/soccer.xml",
            "http://file.mk.co.kr/news/rss/rss_30000001.xml",
            "http://myhome.chosun.com/rss/www_section_rss.xml"};
    String encoding[] = {"UTF-8","UTF-8","EUC-KR","UTF-8"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner = findViewById(R.id.spinner);
        listView = findViewById(R.id.listView);

//      언론사 이름을 스피너에 넣어준다.
        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_item, news);
        spinner.setAdapter(adapter);

//      선택된 스피너의 언론사에 해당되는 뉴스를 얻어와 ListView에 뿌려준다.
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
//              Asynktask 클래스를 상속받은 객체를 만들고 doInBackground() 메소드를 실행한다.
//              뉴스를 얻어올 rss의 url과 문자 인코딩 방식을 가변 인자 strings로 넘겨야 한다.
                new NewsTask().execute(urlAddr[i], encoding[i]);
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) { }
        });

    }

    class NewsTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... strings) {
//          for(int i=0 ; i<strings.length ; i++) {
//              Log.e("strings[] ", i + " => " + strings[i]);
//          }
            list.clear();
            String urlAddr = strings[0];
            try {
                URL url = new URL(urlAddr);
                XmlPullParser parser = XmlPullParserFactory.newInstance().newPullParser();
                parser.setInput(url.openStream(), strings[1]);
                boolean isItem = false, isTitle = false, isLink = false, isDescription = false,
                        isIamge = false, isAuthor = false, isPubDate = false;
                NewsItem newsItem = null;
                String tagName = "";
                int eventType = parser.getEventType();

                while(eventType != XmlPullParser.END_DOCUMENT) {
                    switch (eventType) {
                        case XmlPullParser.START_TAG:
                            tagName = parser.getName();
                            switch (tagName.toLowerCase()) {
                                case "item":
                                    newsItem = new NewsItem();
                                    isItem = true;
                                    break;
                                case "title":
                                    isTitle = true;
                                    break;
                                case "link":
                                    isLink = true;
                                    break;
                                case "description":
                                    isDescription = true;
                                    break;
                                case "image":
                                    isIamge = true;
                                    break;
                                case "author":
                                    isAuthor = true;
                                    break;
                                case "pubDate":
                                    isPubDate = true;
                                    break;
                            }
                            break;
                        case XmlPullParser.END_TAG:
                            tagName = parser.getName();
                            switch (tagName.toLowerCase()) {
                                case "item":
                                    list.add(newsItem);
                                    isItem = false;
                                    break;
                                case "title":
                                    isTitle = false;
                                    break;
                                case "link":
                                    isLink = false;
                                    break;
                                case "description":
                                    isDescription = false;
                                    break;
                                case "image":
                                    isIamge = false;
                                    break;
                                case "author":
                                    isAuthor = false;
                                    break;
                                case "pubDate":
                                    isPubDate = false;
                                    break;
                            }
                            break;
                        case XmlPullParser.TEXT:
                            if(isItem && isTitle) {
                                newsItem.setTitle(parser.getText());
                            }
                            if(isItem && isLink) {
                                newsItem.setLink(parser.getText());
                            }
                            if(isItem && isDescription) {
                                newsItem.setDescription(parser.getText());
                            }
                            if(isItem && isIamge) {
                                newsItem.setImage(parser.getText());
                            }
                            if(isItem && isAuthor) {
                                newsItem.setAuthor(parser.getText());
                            }
                            if(isItem && isPubDate) {
                                newsItem.setPubDate(parser.getText());
                            }
                            break;
                    }
                    eventType = parser.next();
//                    Log.e("News ", newsItem.toString());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
//          언론사별 RSS XML 파일에서 읽어온 뉴스 정보를 Adapter를 만들어 ListView에 올려준다.
            NewsItemAdapter adapter = new NewsItemAdapter(getApplicationContext(), list);
            listView.setAdapter(adapter);
//          ListView가 클릭되면 새 액티비티에 클릭된 뉴스를 표시한다.
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(list.get(i).getLink()));
                    startActivity(intent);
                }
            });
        }

    }

}
