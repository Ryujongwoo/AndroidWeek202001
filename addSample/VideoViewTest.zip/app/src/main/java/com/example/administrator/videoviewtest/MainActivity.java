package com.example.administrator.videoviewtest;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {

    Button playBtn;
    VideoView videoView;
    String videoUrl = "http://sites.google.com/site/ubiaccessmobile/sample_video.mp4";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        playBtn = findViewById(R.id.playBtn);
//      동영상 재생 준비가 완료되기 전 까지 동영상 재생 버튼을 비활성화 시킨다.
        playBtn.setEnabled(false);

        videoView = findViewById(R.id.videoView);
//      동영상을 재생하기 위해 MediaController 객체를 생성한다.
        MediaController mc = new MediaController(this);
//      동영상이 재생될 때 클릭하면 동영상 재생을 컨트롤 할 수 있게 재생/정지, 되감기, 빨리감기와 Progress Slider를
//      표시한다. 아래 코드를 추가시키지 않으면 동영상을 클릭하면 앱이 강제 종료된다.
        mc.setAnchorView(videoView);
//      VideoView에 동영상을 재생하기 위한 MediaController 객체를 대입한다.
        videoView.setMediaController(mc);

//      원격지의 동영상을 읽어서 재생한다.
//      videoView.setVideoURI(Uri.parse(videoUrl));
//      res 폴더 아래의 raw 폴더의 내용을 읽어 재생한다.
        Uri video = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.contents_0686);
        videoView.setVideoURI(video);

//      동영상 재생 준비가 완료되면 실행되는 리스너
        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                Toast.makeText(getApplicationContext(), "재생 준비 완료", Toast.LENGTH_SHORT).show();
//              동영상 재생 준비가 완료되면 동영상 재생 버튼을 활성화 시킨다.
                playBtn.setEnabled(true);
            }
        });

//      동영상 재생이 완료되면 실행되는 리스너
        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                Toast.makeText(getApplicationContext(), "재생 완료", Toast.LENGTH_SHORT).show();
                playBtn.setEnabled(true);
            }
        });
    }

    public void play(View view) {
        playBtn.setEnabled(false);
//      재생하기 버튼이 클릭되면 동영상을 재생한다.
        videoView.start();
    }
}
