package com.example.administrator.externalfiletest;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    EditText editText;
    Button saveBtn, readBtn;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = findViewById(R.id.editText);
        saveBtn = findViewById(R.id.saveBtn);
        readBtn = findViewById(R.id.readBtn);
        textView = findViewById(R.id.textView);
//      두 개 버튼을 사용하지 못하게 한다.
        saveBtn.setEnabled(false);
        readBtn.setEnabled(false);
//      권한을 요청하는 메소드를 실행한다.
        checkPermission();
    }

    public void saveBtn(View view) {
//      외부 파일로 출력하기 위해 EditText에 입력한 내용을 얻어온다.
        String content = editText.getText().toString().trim();
        if(content.length() > 0) {
//          외부 파일로 출력할 객체를 선언한다.
            PrintWriter printWriter = null;
//          외부 기억장치의 절대 경로를 얻어온다.
            String path = Environment.getExternalStorageDirectory().getAbsolutePath();
//          출력할 파일 이름을 지정한다.
            String filename = "sample.txt";
//          파일을 저장할 경로와 파일 이름을 생성자의 인수로 넘겨 File 객체를 만든다.
            File file = new File(path, filename);
            try {
//              외부 파일로 출력할 객체를 선언한다.
//              외부로 출력된 파일은 Device File Explorer의 storage > emulatrded > 0 아래에 생성된다.
                printWriter = new PrintWriter(file);
                printWriter.write(content + "\n");
                printWriter.flush();
                editText.setText("");
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } finally {
                if(printWriter != null) { printWriter.close(); }
            }
        }
    }

    public void readBtn(View view) {
        String path = Environment.getExternalStorageDirectory().getAbsolutePath();
        String filename = "sample.txt";
        File file = new File(path, filename);
        Scanner sc = null;
        try {
            sc = new Scanner(file, "UTF-8");
            textView.setText("");
//          파일에서 더 이상 읽을 줄이 없을 때 까지 반복하며 파일 내용을 읽어 TextView에 출력한다.
            while (sc.hasNextLine()) {
                textView.append(sc.nextLine() + "\n");
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            if(sc != null) { sc.close(); }
        }
    }

//  마시멜로우 버전 이후에 해야하는 권한을 요청하는 메소드
    private void checkPermission() {
//
//      Build.VERSION.SDK_INT : 현재 설치된 안드로이드의 버전
//      Toast.makeText(getApplicationContext(), Build.VERSION.SDK_INT + "", Toast.LENGTH_SHORT).show();
//      Build.VERSION_CODES.M : 마시멜로우
//      Toast.makeText(getApplicationContext(), Build.VERSION_CODES.M + "", Toast.LENGTH_SHORT).show();
//      현재 설치된 안드로이드 버전이 마시멜로우 이상이라면 권한이 있는가 하는 여부를 확인한다.
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//          Manifest.permission.WRITE_EXTERNAL_STORAGE : 외부 저장소로 쓰기 권한
//          Manifest.permission.READ_EXTERNAL_STORAGE : 외부 저장소에서 읽기 권한
//          PackageManager.PERMISSION_GRANTED : 권한 있음
            if(checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(getApplicationContext(), "권한 없음", Toast.LENGTH_SHORT).show();

//              권한이 없다면 설치 후 권한을 제거했을 때 처리하는 내용을 작성한다.
                if(shouldShowRequestPermissionRationale(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    Toast.makeText(getApplicationContext(),
                            "외부 기억 장소로 접근하려면 권한을 부여해야 합니다.", Toast.LENGTH_SHORT).show();
                }

//              권한을 요청하는 내용을 작성한다.
//              권한을 요청할 경우 반드시 권한을 허락했을 때 코드와 권한을 거부했을 때 코드를 작성하기 위해서
//              onRequestPermissionsResult() 콜백 메소드를 작성해야 한다.
                requestPermissions(new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE}, 1004);
            } else {
                Toast.makeText(getApplicationContext(), "권한 있음", Toast.LENGTH_SHORT).show();
//              권한이 있다면 두 개의 버튼을 활성화 시킨다.
                saveBtn.setEnabled(true);
                readBtn.setEnabled(true);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(grantResults[0] == PackageManager.PERMISSION_GRANTED &&
                grantResults[1] == PackageManager.PERMISSION_GRANTED) {
//          권한을 허락했을 때 코드를 작성한다.
            Toast.makeText(getApplicationContext(), "권한 승인", Toast.LENGTH_SHORT).show();
            saveBtn.setEnabled(true);
            readBtn.setEnabled(true);
        } else {
//          권한을 거부했을 때 코드를 작성한다.
            Toast.makeText(getApplicationContext(), "권한 거부", Toast.LENGTH_SHORT).show();
            saveBtn.setEnabled(false);
            readBtn.setEnabled(false);
        }
    }
}















